/********************************************************************************
** Form generated from reading UI file 'Moxybox.ui'
**
** Created by: Qt User Interface Compiler version 5.11.2
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_MOXYBOX_H
#define UI_MOXYBOX_H

#include <QtCore/QVariant>
#include <QtWidgets/QApplication>
#include <QtWidgets/QMainWindow>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_MoxyboxClass
{
public:
    QWidget *centralWidget;

    void setupUi(QMainWindow *MoxyboxClass)
    {
        if (MoxyboxClass->objectName().isEmpty())
            MoxyboxClass->setObjectName(QStringLiteral("MoxyboxClass"));
        MoxyboxClass->resize(800, 600);
        centralWidget = new QWidget(MoxyboxClass);
        centralWidget->setObjectName(QStringLiteral("centralWidget"));
        MoxyboxClass->setCentralWidget(centralWidget);

        retranslateUi(MoxyboxClass);

        QMetaObject::connectSlotsByName(MoxyboxClass);
    } // setupUi

    void retranslateUi(QMainWindow *MoxyboxClass)
    {
        MoxyboxClass->setWindowTitle(QApplication::translate("MoxyboxClass", "Moxybox", nullptr));
    } // retranslateUi

};

namespace Ui {
    class MoxyboxClass: public Ui_MoxyboxClass {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_MOXYBOX_H
