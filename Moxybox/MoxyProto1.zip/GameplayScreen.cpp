#include "GameplayScreen.h"

// Possibly see if there's a neat way to tell user what is using a keybind if it's already in use,
// when modifying.

// Possibly implement collision detection for patrollers when hitting blocks or hazards.
// (as in, they can't land on them)

// honestly though, might be fine to leave it as a possibility that they can go on/over them.
// could make for more dynamic level design possibilities.


// !important: Need to build an installer that can install Pixellari font. 
// Otherwise, people using the program won't have it...

// reset level doesn't appear to be setting the facing of patrollers back to default???

GameplayScreen::GameplayScreen(QWidget *parent)
	: QGraphicsView(parent)
{
	modLoadThemeIfExists();
	prefLoad();

	setStyleSheet(baseStyle);
	setAlignment(Qt::AlignTop | Qt::AlignLeft);

	scene.get()->setParent(this->parent());
	setScene(scene.get());

	splashItem.get()->setPixmap(imgSplashTitle);
	splashItem.get()->setZValue(splashZ);
	scene.get()->addItem(splashItem.get());

	uiGameplayGroup->setVisible(false);

	uiGameplayFontGroupTitle.setFamily(standardFontFamily);
	uiGameplayFontGroupTitle.setPointSize(uiGameplayFontGroupTitle_fontPointSize);
	uiGameplayFontGroupTitle.setStyleStrategy(standardFontStyleStrategy);
	uiGameplayFontGroupTitle.setWeight(standardFontWeight);

	uiGameplayFontTextBox.setFamily(standardFontFamily);
	uiGameplayFontTextBox.setPointSize(uiGameplayFontTextBox_fontPointSize);
	uiGameplayFontTextBox.setStyleStrategy(standardFontStyleStrategy);
	uiGameplayFontTextBox.setWeight(standardFontWeight);

	uiGameplayGroup.get()->setGeometry(QRect(0, 401, 800, 200));
	uiGameplayGroup.get()->setLayout(uiGameplayLayout.get());
	uiGameplayGroup.get()->setFlat(true);
	uiGameplayLayout.get()->setMargin(3);
	uiGameplayLayout.get()->addWidget(uiGameplayStatsGroup.get(), 0, 0);
	uiGameplayLayout.get()->addWidget(uiGameplayObjectivesGroup.get(), 0, 1);
	uiGameplayLayout.get()->addWidget(uiGameplayKeymapGroup.get(), 0, 3);
	uiGameplayLayout.get()->addWidget(uiGameplayMessagesGroup.get(), 0, 2);

	uiGameplayStatsGroup.get()->setLayout(uiGameplayStatsLayout.get());
	uiGameplayStatsGroup.get()->setMinimumWidth(minBoxWidth);
	uiGameplayStatsLayout.get()->setContentsMargins(5, 25, 0, 5);
	uiGameplayStatsLayout.get()->setAlignment(Qt::AlignLeft | Qt::AlignTop);
	uiGameplayStatsLayout.get()->addWidget(uiGameplayStatsCounterTurns.get(), 0, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayStatsLayout.get()->addWidget(uiGameplayStatsCounterKeys.get(), 1, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayStatsLayout.get()->addWidget(uiGameplayStatsCounterTrapPushers.get(), 2, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayStatsLayout.get()->addWidget(uiGameplayStatsCounterTrapSuckers.get(), 3, 0, Qt::AlignLeft | Qt::AlignTop);

	uiGameplayStatsCounterTurns.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayStatsCounterTurns.get()->setFont(uiGameplayFontTextBox);

	uiGameplayStatsCounterKeys.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayStatsCounterKeys.get()->setFont(uiGameplayFontTextBox);

	uiGameplayStatsCounterTrapPushers.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayStatsCounterTrapPushers.get()->setFont(uiGameplayFontTextBox);

	uiGameplayStatsCounterTrapSuckers.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayStatsCounterTrapSuckers.get()->setFont(uiGameplayFontTextBox);

	uiGameplayObjectivesGroup.get()->setLayout(uiGameplayObjectivesLayout.get());
	uiGameplayObjectivesGroup.get()->setMinimumWidth(minBoxWidth);
	uiGameplayObjectivesLayout.get()->setContentsMargins(5, 20, 0, 5);
	uiGameplayObjectivesLayout.get()->setAlignment(Qt::AlignLeft | Qt::AlignTop);
	uiGameplayObjectivesLayout.get()->addWidget(uiGameplayObjectivesTextBox.get(), 0, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayObjectivesTextBox.get()->setStyleSheet(uiGameplayTextBoxStyle);
	uiGameplayObjectivesTextBox.get()->setFont(uiGameplayFontTextBox);
	uiGameplayObjectivesTextBox.get()->setText("Collect Keys\nOpen Pods with Keys");

	uiGameplayMessagesGroup.get()->setLayout(uiGameplayMessagesLayout.get());
	uiGameplayMessagesGroup.get()->setMinimumWidth(minBoxWidth);
	uiGameplayMessagesLayout.get()->setContentsMargins(5, 20, 0, 5);
	uiGameplayMessagesLayout.get()->setAlignment(Qt::AlignLeft | Qt::AlignTop);
	uiGameplayMessagesLayout.get()->addWidget(uiGameplayMessagesTextBox.get(), 0, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayMessagesTextBox.get()->setStyleSheet(uiGameplayTextBoxStyle);
	uiGameplayMessagesTextBox.get()->setFont(uiGameplayFontTextBox);

	uiGameplayKeymapGroup.get()->setLayout(uiGameplayKeymapLayout.get());
	uiGameplayKeymapGroup.get()->setMinimumWidth(minBoxWidth);
	uiGameplayKeymapLayout.get()->setContentsMargins(5, 20, 0, 5);
	uiGameplayKeymapLayout.get()->setAlignment(Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnMoveLeft.get(), 0, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelMoveLeft.get(), 0, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnMoveRight.get(), 1, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelMoveRight.get(), 1, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnMoveUp.get(), 2, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelMoveUp.get(), 2, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnMoveDown.get(), 3, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelMoveDown.get(), 3, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnPlacePusherUtil.get(), 4, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelPlacePusherUtil.get(), 4, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnPlaceSuckerUtil.get(), 5, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelPlaceSuckerUtil.get(), 5, 1, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapBtnOpenMenu.get(), 6, 0, Qt::AlignLeft | Qt::AlignTop);
	uiGameplayKeymapLayout.get()->addWidget(uiGameplayKeymapLabelOpenMenu.get(), 6, 1, Qt::AlignLeft | Qt::AlignTop);

	uiGameplayKeymapBtnMoveLeft.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnMoveLeft.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnMoveLeft.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnMoveLeft.get()->setText(QKeySequence(keybindMoveLeft).toString());

	uiGameplayKeymapLabelMoveLeft.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelMoveLeft.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelMoveLeft.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelMoveLeft.get()->setText("Move Left");

	uiGameplayKeymapBtnMoveRight.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnMoveRight.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnMoveRight.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnMoveRight.get()->setText(QKeySequence(keybindMoveRight).toString());

	uiGameplayKeymapLabelMoveRight.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelMoveRight.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelMoveRight.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelMoveRight.get()->setText("Move Right");

	uiGameplayKeymapBtnMoveUp.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnMoveUp.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnMoveUp.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnMoveUp.get()->setText(QKeySequence(keybindMoveUp).toString());

	uiGameplayKeymapLabelMoveUp.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelMoveUp.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelMoveUp.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelMoveUp.get()->setText("Move Up");

	uiGameplayKeymapBtnMoveDown.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnMoveDown.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnMoveDown.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnMoveDown.get()->setText(QKeySequence(keybindMoveDown).toString());

	uiGameplayKeymapLabelMoveDown.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelMoveDown.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelMoveDown.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelMoveDown.get()->setText("Move Down");

	uiGameplayKeymapBtnPlacePusherUtil.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnPlacePusherUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnPlacePusherUtil.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnPlacePusherUtil.get()->setText(QKeySequence(keybindPlacePusherUtil).toString());

	uiGameplayKeymapLabelPlacePusherUtil.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelPlacePusherUtil.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelPlacePusherUtil.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelPlacePusherUtil.get()->setText("Place Magnet");

	uiGameplayKeymapBtnPlaceSuckerUtil.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnPlaceSuckerUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnPlaceSuckerUtil.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnPlaceSuckerUtil.get()->setText(QKeySequence(keybindPlaceSuckerUtil).toString());

	uiGameplayKeymapLabelPlaceSuckerUtil.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelPlaceSuckerUtil.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelPlaceSuckerUtil.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelPlaceSuckerUtil.get()->setText("Place Spring");

	uiGameplayKeymapBtnOpenMenu.get()->setMinimumSize(QSize(uiGameplayKeymapBtnSize, uiGameplayKeymapBtnSize));
	uiGameplayKeymapBtnOpenMenu.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
	uiGameplayKeymapBtnOpenMenu.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapBtnOpenMenu.get()->setText(QKeySequence(keybindOpenMenu).toString());

	uiGameplayKeymapLabelOpenMenu.get()->setMinimumHeight(uiGameplayKeymapBtnSize);
	uiGameplayKeymapLabelOpenMenu.get()->setStyleSheet(uiGameplayLabelStyle);
	uiGameplayKeymapLabelOpenMenu.get()->setFont(uiGameplayFontTextBox);
	uiGameplayKeymapLabelOpenMenu.get()->setText("Open Menu");

	// Lot of boilerplate here that could probably be improved.
	// Hi, future me. I never did reduce this, did I?

	connect(uiGameplayKeymapBtnMoveLeft.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnMoveLeft.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::MOVE_LEFT;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnMoveLeft.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnMoveRight.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnMoveRight.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::MOVE_RIGHT;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnMoveRight.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnMoveUp.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnMoveUp.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::MOVE_UP;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnMoveUp.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnMoveDown.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnMoveDown.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::MOVE_DOWN;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnMoveDown.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnPlacePusherUtil.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnPlacePusherUtil.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::PLACE_PUSHER_UTIL;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnPlacePusherUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnPlaceSuckerUtil.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnPlaceSuckerUtil.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::PLACE_SUCKER_UTIL;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnPlaceSuckerUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	connect(uiGameplayKeymapBtnOpenMenu.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PLAYING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleKeybinding);
			uiGameplayKeymapBtnOpenMenu.get()->setStyleSheet(uiGameplayKeymapModifBtnStyle);
			keybindToModify = KeybindModifiable::OPEN_MENU;
			gameState = GameState::KEYBINDING;
		}
		else if (gameState == GameState::KEYBINDING)
		{
			uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
			uiGameplayKeymapBtnOpenMenu.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
			keybindToModify = KeybindModifiable::NONE;
			gameState = GameState::PLAYING;
		}
	});

	uiGameplayStatsGroup.get()->setFont(uiGameplayFontGroupTitle);
	uiGameplayObjectivesGroup.get()->setFont(uiGameplayFontGroupTitle);
	uiGameplayMessagesGroup.get()->setFont(uiGameplayFontGroupTitle);
	uiGameplayKeymapGroup.get()->setFont(uiGameplayFontGroupTitle);

	uiGameplayStatsGroup.get()->setStyleSheet(uiGameplayGroupBoxStyle);
	uiGameplayObjectivesGroup.get()->setStyleSheet(uiGameplayGroupBoxStyle);
	uiGameplayMessagesGroup.get()->setStyleSheet(uiGameplayGroupBoxStyle);
	uiGameplayKeymapGroup.get()->setStyleSheet(uiGameplayGroupBoxStyle);

	uiGameplayStatsGroup.get()->setTitle("Stats");
	uiGameplayObjectivesGroup.get()->setTitle("Objectives");
	uiGameplayMessagesGroup.get()->setTitle("Messages");
	uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);

	uiMenuFontBtn.setFamily(standardFontFamily);
	uiMenuFontBtn.setPointSize(uiMenuFontBtn_fontPointSize);
	uiMenuFontBtn.setStyleStrategy(standardFontStyleStrategy);
	uiMenuFontBtn.setWeight(standardFontWeight);

	uiMenuGroup.get()->setGeometry(QRect(293, 125, 214, 350));
	uiMenuGroup.get()->setLayout(uiMenuLayout.get());
	uiMenuGroup.get()->setFlat(true);
	uiMenuGroup.get()->setStyleSheet(uiMenuGroupBoxStyle);
	uiMenuLayout.get()->setMargin(0);
	uiMenuLayout.get()->setRowMinimumHeight(0, uiMenuBtnMinRowHeight);
	uiMenuLayout.get()->setRowMinimumHeight(1, uiMenuBtnMinRowHeight);
	uiMenuLayout.get()->setRowMinimumHeight(2, uiMenuBtnMinRowHeight);
	uiMenuLayout.get()->setRowMinimumHeight(3, uiMenuBtnMinRowHeight);
	uiMenuLayout.get()->setAlignment(Qt::AlignTop);
	uiMenuLayout.get()->addWidget(uiMenuBtnResume.get(), 0, 0, Qt::AlignTop);
	uiMenuLayout.get()->addWidget(uiMenuBtnSave.get(), 1, 0, Qt::AlignTop);
	uiMenuLayout.get()->addWidget(uiMenuBtnLoad.get(), 2, 0, Qt::AlignTop);
	uiMenuLayout.get()->addWidget(uiMenuBtnReset.get(), 3, 0, Qt::AlignTop);
	uiMenuLayout.get()->addWidget(uiMenuBtnExit.get(), 4, 0, Qt::AlignTop);

	uiMenuBtnResume.get()->setFixedSize(QSize(uiMenuBtnWidth, uiMenuBtnHeight));
	uiMenuBtnResume.get()->setStyleSheet(uiMenuBtnStyle);
	uiMenuBtnResume.get()->setFont(uiMenuFontBtn);
	uiMenuBtnResume.get()->setText("RESUME");

	uiMenuBtnSave.get()->setFixedSize(QSize(uiMenuBtnWidth, uiMenuBtnHeight));
	uiMenuBtnSave.get()->setStyleSheet(uiMenuBtnStyle);
	uiMenuBtnSave.get()->setFont(uiMenuFontBtn);
	uiMenuBtnSave.get()->setText("SAVE");

	uiMenuBtnLoad.get()->setFixedSize(QSize(uiMenuBtnWidth, uiMenuBtnHeight));
	uiMenuBtnLoad.get()->setStyleSheet(uiMenuBtnStyle);
	uiMenuBtnLoad.get()->setFont(uiMenuFontBtn);
	uiMenuBtnLoad.get()->setText("LOAD");

	uiMenuBtnReset.get()->setFixedSize(QSize(uiMenuBtnWidth, uiMenuBtnHeight));
	uiMenuBtnReset.get()->setStyleSheet(uiMenuBtnStyle);
	uiMenuBtnReset.get()->setFont(uiMenuFontBtn);
	uiMenuBtnReset.get()->setText("RESET LEVEL");

	uiMenuBtnExit.get()->setFixedSize(QSize(uiMenuBtnWidth, uiMenuBtnHeight));
	uiMenuBtnExit.get()->setStyleSheet(uiMenuBtnStyle);
	uiMenuBtnExit.get()->setFont(uiMenuFontBtn);
	uiMenuBtnExit.get()->setText("EXIT GAME");

	connect(uiMenuBtnResume.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PAUSED)
		{
			uiMenuResumePlay();
		}
	});

	connect(uiMenuBtnSave.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PAUSED)
		{
			// Id is important here. We use unique Id in save/load process,
			// to ensure that we're loading in the correct level with the right amount of progress.
			// Note: Should probably make it so saving only saves progress in current level.
			// and can Load you into current level, if it exists in the level list.

			// actually, we might be able to save progress on all levels in the list.
			// give them a state that can be set to "COMPLETE" or "INCOMPLETE" or "INPROGRESS"
			// Save file will have a list of levels that are marked "COMPLETE"
			// if those levels exist in the loaded list, they will get their state changed to COMPLETE
			// there should only be one that is INPROGRESS, that will be what is set to the current level on load
			// if it exists in the loaded list

			QString proposedSaveName;
			proposedSaveName += fileDirLastSaved + "/";
			proposedSaveName += QDateTime::currentDateTime().toString("_yyyy_MM_dd_HH_mm_ss");
			QFileDialog dialog(this, tr("Save As"), proposedSaveName, tr("Moxybox Files (*.MoxySave)"));
			dialog.setWindowModality(Qt::WindowModal);
			dialog.setAcceptMode(QFileDialog::AcceptSave);
			if (dialog.exec() == QFileDialog::Accepted)
			{
				QString fpath = dialog.selectedFiles().first();
				QFile fileWrite(fpath);
				if (fileWrite.open(QIODevice::WriteOnly))
				{
					QTextStream qStream(&fileWrite);

					// need to store state of immobile objects
					// store keys # held
					// store traps # held (and which ones are held)
					//	- maybe I can simplify the logic here, make a "HELD" state for traps
					//	in this way, if the state is HELD, I know player has it?
					// idk, we'll see...
					// could make HELD state for keys too maybe...
					// not sure this HELD logic is actually necessary...

					qStream <<
						"::"
						"Id=" + levelsAll[levelCurrent].id +
						"::" +
						"Difficulty=" + QString::number(levelsAll[levelCurrent].difficulty) +
						"::" +
						"TurnsRemaining=" + QString::number(levelsAll[levelCurrent].turnsRemaining) +
						"::"
						"KeysHeld=" + QString::number(levelsAll[levelCurrent].players[pIndex].heldKeys) +
						"::"
						"TrapsPusherHeldNum=" + QString::number(levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.size()) +
						"::"
						"TrapsSuckerHeldNum=" + QString::number(levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.size()) +
						"::";

					qStream << "TrapsPusherHeldIndices=";
					for (const auto& heldIndex : levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex)
					{
						qStream << "(" + QString::number(heldIndex) + ")";
					}
					qStream << "::";

					qStream << "TrapsSuckerHeldIndices=";
					for (const auto& heldIndex : levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex)
					{
						qStream << "(" + QString::number(heldIndex) + ")";
					}
					qStream << "::";

					qStream << "\r\n";

					qStream << "::Gate=";
					for (const auto& gate : levelsAll[levelCurrent].gates)
					{
						qStream <<
							"(" +
							QString::number(gate.item.get()->x()) +
							"," +
							QString::number(gate.item.get()->y()) +
							"," +
							tokenImmobile::stateToString(gate.state) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Key=";
					for (const auto& key : levelsAll[levelCurrent].keys)
					{
						qStream <<
							"(" +
							QString::number(key.item.get()->x()) +
							"," +
							QString::number(key.item.get()->y()) +
							"," +
							tokenImmobile::stateToString(key.state) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Player=";
					for (const auto& player : levelsAll[levelCurrent].players)
					{
						qStream <<
							QString::number(player.item.get()->x()) +
							"," +
							QString::number(player.item.get()->y());
					}
					qStream << "::\r\n";

					qStream << "::Pusher=";
					for (auto& pusher : levelsAll[levelCurrent].pushers)
					{
						qStream <<
							"(" +
							QString::number(pusher.item.get()->x()) +
							"," +
							QString::number(pusher.item.get()->y()) +
							"," +
							tokenPatroller::facingToString(pusher.facing) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Sucker=";
					for (auto& sucker : levelsAll[levelCurrent].suckers)
					{
						qStream <<
							"(" +
							QString::number(sucker.item.get()->x()) +
							"," +
							QString::number(sucker.item.get()->y()) +
							"," +
							tokenPatroller::facingToString(sucker.facing) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Util=";
					for (auto& util : levelsAll[levelCurrent].utils)
					{
						qStream <<
							"(" +
							QString::number(util.item.get()->x()) +
							"," +
							QString::number(util.item.get()->y()) +
							"," +
							tokenUtil::typeToString(util.type) +
							"," +
							tokenUtil::stateToString(util.stateModified) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Block=";
					for (auto& block : levelsAll[levelCurrent].blocks)
					{
						qStream <<
							"(" +
							QString::number(block.item.get()->x()) +
							"," +
							QString::number(block.item.get()->y()) +
							"," +
							tokenImmobile::stateToString(block.state) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::Hazard=";
					for (auto& hazard : levelsAll[levelCurrent].hazards)
					{
						qStream <<
							"(" +
							QString::number(hazard.item.get()->x()) +
							"," +
							QString::number(hazard.item.get()->y()) +
							"," +
							tokenImmobile::stateToString(hazard.state) +
							")";
					}
					qStream << "::\r\n";

					qStream << "::LevelsComplete=";
					for (const auto& level : levelsAll)
					{
						if (level.id != levelsAll[levelCurrent].id)
						{
							// If a level is complete, store its ID, so we can set it as complete on load
							if (level.state == levelData::State::COMPLETE)
							{
								qStream <<
									"(" +
									level.id +
									")";
							}
						}
					}
					qStream << "::\r\n";

					fileWrite.close();
					fileDirLastSaved = QFileInfo(fpath).path();
				}

				uiMenuResumePlay();
			}
		}
	});

	connect(uiMenuBtnLoad.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PAUSED)
		{
			// reverse the saving process with magical powers of deduction
			QString filename = QFileDialog::getOpenFileName(this, tr("Open"), fileDirLastOpened, tr("Moxybox Files (*.MoxySave)"));
			if (!filename.isEmpty())
			{
				fileDirLastOpened = QFileInfo(filename).path();
				QFile fileRead(filename);
				int levelPos = -1;
				if (fileRead.open(QIODevice::ReadOnly))
				{
					levelPos = levelLoadValidateId(fileRead);
					fileRead.close();
				}

				if (levelPos >= 0)
				{
					if (fileRead.open(QIODevice::ReadOnly))
					{
						if (levelCurrent != levelPos)
						{
							removeCurrentLevelFromScene();
							levelCurrent = levelPos;
							qDebug() << "Current level ID: " << levelsAll[levelCurrent].id;
							addCurrentLevelToScene();
						}

						qDebug() << "Loaded level ID: " << levelsAll[levelPos].id;
						qDebug() << "Current level ID: " << levelsAll[levelCurrent].id;
						QTextStream qStream(&fileRead);
						while (!qStream.atEnd())
						{
							QString line = qStream.readLine();
							if (line.contains("::Id="))
							{
								levelsAll[levelCurrent].turnsRemaining = extractSubstringInbetweenQt("::TurnsRemaining=", "::", line).toInt();
								levelsAll[levelCurrent].difficulty = extractSubstringInbetweenQt("::Difficulty=", "::", line).toInt();
								levelsAll[levelCurrent].players[pIndex].heldKeys = extractSubstringInbetweenQt("::KeysHeld=", "::", line).toInt();

								levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.clear();
								levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.clear();
								levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.resize(extractSubstringInbetweenQt("::TrapsPusherHeldNum=", "::", line).toInt());
								levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.resize(extractSubstringInbetweenQt("::TrapsSuckerHeldNum=", "::", line).toInt());

								QString utilPushLine = extractSubstringInbetweenQt("::TrapsPusherHeldIndices=", "::", line);
								QStringList utilPushList = extractSubstringInbetweenQtLoopList("(", ")", utilPushLine);

								for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.size(); i++)
								{
									levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex[i] = utilPushList[i].toInt();
								}

								QString utilSuckLine = extractSubstringInbetweenQt("::TrapsSuckerHeldIndices=", "::", line);
								QStringList utilSuckList = extractSubstringInbetweenQtLoopList("(", ")", utilSuckLine);

								for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.size(); i++)
								{
									levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex[i] = utilSuckList[i].toInt();
								}

								uiGameplayUpdateStatCounterTurns();
								uiGameplayUpdateStatCounterKeys();
								uiGameplayUpdateStatCounterPushers();
								uiGameplayUpdateStatCounterSuckers();
							}
							else if (line.contains("::Gate="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Gate=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].gates[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].gates[i].state = tokenImmobile::stateToEnum(components[2]);
									levelsAll[levelCurrent].gates[i].item.get()->setPixmap
									(
										stateToImg(levelsAll[levelCurrent].gates[i].state, levelsAll[levelCurrent].gates[i].type)
									);
								}
							}
							else if (line.contains("::Key="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Key=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].keys[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].keys[i].state = tokenImmobile::stateToEnum(components[2]);
									levelsAll[levelCurrent].keys[i].item.get()->setPixmap
									(
										stateToImg(levelsAll[levelCurrent].keys[i].state, levelsAll[levelCurrent].keys[i].type)
									);
								}
							}
							else if (line.contains("::Player="))
							{
								QStringList components = extractSubstringInbetweenQt("::Player=", "::", line).split(",", QString::SkipEmptyParts);
								levelsAll[levelCurrent].players[pIndex].item.get()->setPos
								(
									components[0].toInt(),
									components[1].toInt()
								);
							}
							else if (line.contains("::Pusher="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Pusher=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].pushers[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].pushers[i].facing = tokenPatroller::facingToEnum(components[2]);
									levelsAll[levelCurrent].pushers[i].item.get()->setPixmap
									(
										facingToImg(levelsAll[levelCurrent].pushers[i].facing, levelsAll[levelCurrent].pushers[i].type)
									);
								}
							}
							else if (line.contains("::Sucker="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Sucker=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].suckers[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].suckers[i].facing = tokenPatroller::facingToEnum(components[2]);
									levelsAll[levelCurrent].suckers[i].item.get()->setPixmap
									(
										facingToImg(levelsAll[levelCurrent].suckers[i].facing, levelsAll[levelCurrent].suckers[i].type)
									);
								}
							}
							else if (line.contains("::Util="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Util=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].utils[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].utils[i].type = levelsAll[levelCurrent].utils[i].typeToEnum(components[2]);
									levelsAll[levelCurrent].utils[i].stateModified = tokenUtil::stateToEnum(components[3]);
									levelsAll[levelCurrent].utils[i].item.get()->setPixmap
									(
										stateToImg(levelsAll[levelCurrent].utils[i].stateModified, levelsAll[levelCurrent].utils[i].type)
									);
								}
							}
							else if (line.contains("::Block="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Block=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].blocks[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].blocks[i].state = tokenImmobile::stateToEnum(components[2]);
									levelsAll[levelCurrent].blocks[i].item.get()->setPixmap
									(
										stateToImg(levelsAll[levelCurrent].blocks[i].state, levelsAll[levelCurrent].blocks[i].type)
									);
								}
							}
							else if (line.contains("::Hazard="))
							{
								QString dataLine = extractSubstringInbetweenQt("::Hazard=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									QStringList components = dataList[i].split(",", QString::SkipEmptyParts);
									levelsAll[levelCurrent].hazards[i].item.get()->setPos
									(
										components[0].toInt(),
										components[1].toInt()
									);
									levelsAll[levelCurrent].hazards[i].state = tokenImmobile::stateToEnum(components[2]);
									levelsAll[levelCurrent].hazards[i].item.get()->setPixmap
									(
										stateToImg(levelsAll[levelCurrent].hazards[i].state, levelsAll[levelCurrent].hazards[i].type)
									);
								}
							}
							else if (line.contains("::LevelsComplete="))
							{
								QString dataLine = extractSubstringInbetweenQt("::LevelsComplete=", "::", line);
								QStringList dataList = extractSubstringInbetweenQtLoopList("(", ")", dataLine);

								for (int i = 0; i < dataList.length(); i++)
								{
									int levelPos = levelFoundInListAtPos(dataList[i]);
									if (levelPos >= 0)
									{
										levelsAll[levelPos].state = levelData::State::COMPLETE;
									}
								}
							}
						}
						fileRead.close();
						uiMenuResumePlay();
					}
				}
				else
				{
					QMessageBox::information(this->parentWidget(),
						tr("Level Not Found"),
						tr("Saved level ID was not found in loaded levels.\r\nSave file only saves references to existing levels, so if they are moved or deleted, loading may fail.")
					);
				}
			}
		}
	});

	connect(uiMenuBtnReset.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PAUSED)
		{
			uiMenuResumePlay();
			levelSetToDefaults(levelsAll[levelCurrent]);
			uiGameplaySetToDefaults();
			uiGameplayGroup->setVisible(true);
			gameState = GameState::PLAYING;
			turnOwner = TurnOwner::PLAYER;
		}
	});

	connect(uiMenuBtnExit.get(), &QPushButton::clicked, this, [=]() {
		if (gameState == GameState::PAUSED)
		{
			this->parentWidget()->parentWidget()->close();
		}
	});

	uiMenuGroup.get()->setVisible(false);

	// GRID CORNER
	gridPiecesCorner.reserve(4);

	gridPieceCorner cornerUpL;
	cornerUpL.item.get()->setPixmap(imgGridCornerUpL);
	cornerUpL.item.get()->setPos(gridAnchorX, gridAnchorY);
	cornerUpL.facing = gridPieceCorner::Facing::UP_LEFT;
	gridPiecesCorner.emplace_back(std::move(cornerUpL));

	gridPieceCorner cornerUpR;
	cornerUpR.item.get()->setPixmap(imgGridCornerUpR);
	cornerUpR.item.get()->setPos(gridBoundRight - gridPieceSize, gridAnchorY);
	cornerUpR.facing = gridPieceCorner::Facing::UP_RIGHT;
	gridPiecesCorner.emplace_back(std::move(cornerUpR));

	gridPieceCorner cornerDownL;
	cornerDownL.item.get()->setPixmap(imgGridCornerDownL);
	cornerDownL.item.get()->setPos(gridAnchorX, gridBoundDown - gridPieceSize);
	cornerDownL.facing = gridPieceCorner::Facing::DOWN_LEFT;
	gridPiecesCorner.emplace_back(std::move(cornerDownL));

	gridPieceCorner cornerDownR;
	cornerDownR.item.get()->setPixmap(imgGridCornerDownR);
	cornerDownR.item.get()->setPos(gridBoundRight - gridPieceSize, gridBoundDown - gridPieceSize);
	cornerDownR.facing = gridPieceCorner::Facing::DOWN_RIGHT;
	gridPiecesCorner.emplace_back(std::move(cornerDownR));

	for (auto& piece : gridPiecesCorner)
	{
		piece.item.get()->setZValue(gridPieceZ);
		scene.get()->addItem(piece.item.get());
	}


	// GRID INNER
	const int gridInnerXConst = gridAnchorX + gridPieceSize;
	int gridInnerY = gridAnchorY + gridPieceSize;
	int gridInnerX = gridInnerXConst;
	const int downInnerTotal = gridColSize - 2;
	const int acrossInnerTotal = gridRowSize - 2;
	gridPiecesInner.reserve(downInnerTotal * acrossInnerTotal);
	for (int downInner = 0; downInner < downInnerTotal; downInner++)
	{
		for (int acrossInner = 0; acrossInner < acrossInnerTotal; acrossInner++)
		{
			gridPieceInner piece;
			piece.item.get()->setPixmap(imgGridInner);
			piece.item.get()->setPos(gridInnerX, gridInnerY);
			gridPiecesInner.emplace_back(std::move(piece));

			gridInnerX += gridPieceSize;
		}
		gridInnerY += gridPieceSize;
		gridInnerX = gridInnerXConst;
	}

	for (auto& piece : gridPiecesInner)
	{
		piece.item.get()->setZValue(gridPieceZ);
		scene.get()->addItem(piece.item.get());
	}


	// GRID EDGE
	const int numEdgesHorizontal = gridRowSize - 2;
	const int numEdgesVertical = gridColSize - 2;
	gridPiecesEdge.reserve(numEdgesHorizontal * numEdgesVertical);

	// Edge naming convention: X and Y are the directions the tiles are placed in.
	// i.e. UpX is the tiles placed across, at the top.

	int gridPieceEdgeUpX = gridPieceSize + gridAnchorX;
	for (int i = 0; i < numEdgesHorizontal; i++)
	{
		gridPieceEdge piece;
		piece.item.get()->setPixmap(imgGridEdgeUpX);
		piece.item.get()->setPos(gridPieceEdgeUpX, gridAnchorY);
		piece.facing = gridPieceEdge::Facing::UP;
		gridPiecesEdge.emplace_back(std::move(piece));

		gridPieceEdgeUpX += gridPieceSize;
	}

	int gridPieceEdgeDownX = gridPieceSize + gridAnchorX;
	for (int i = 0; i < numEdgesHorizontal; i++)
	{
		gridPieceEdge piece;
		piece.item.get()->setPixmap(imgGridEdgeDownX);
		piece.item.get()->setPos(gridPieceEdgeDownX, gridBoundDown - gridPieceSize);
		piece.facing = gridPieceEdge::Facing::DOWN;
		gridPiecesEdge.emplace_back(std::move(piece));

		gridPieceEdgeDownX += gridPieceSize;
	}

	int gridPieceEdgeLeftY = gridAnchorY + gridPieceSize;
	for (int i = 0; i < numEdgesVertical; i++)
	{
		gridPieceEdge piece;
		piece.item.get()->setPixmap(imgGridEdgeLeftY);
		piece.item.get()->setPos(gridAnchorX, gridPieceEdgeLeftY);
		piece.facing = gridPieceEdge::Facing::LEFT;
		gridPiecesEdge.emplace_back(std::move(piece));

		gridPieceEdgeLeftY += gridPieceSize;
	}

	int gridPieceEdgeRightY = gridAnchorY + gridPieceSize;
	for (int i = 0; i < numEdgesVertical; i++)
	{
		gridPieceEdge piece;
		piece.item.get()->setPixmap(imgGridEdgeRightY);
		piece.item.get()->setPos(gridBoundRight - gridPieceSize, gridPieceEdgeRightY);
		piece.facing = gridPieceEdge::Facing::RIGHT;
		gridPiecesEdge.emplace_back(std::move(piece));

		gridPieceEdgeRightY += gridPieceSize;
	}

	for (auto& piece : gridPiecesEdge)
	{
		piece.item.get()->setZValue(gridPieceZ);
		scene.get()->addItem(piece.item.get());
	}


	// Get all paths of data files and store them in vectors as strings
	qDebug() << levelDataPath;
	QDirIterator dirIt(levelDataPath, QDir::AllEntries | QDir::NoDotAndDotDot);
	while (dirIt.hasNext())
	{
		QString filePath = dirIt.next();
		qDebug() << filePath;

		if (QFileInfo(filePath).suffix() != levelDataFileExtension)
			continue;

		QString fileContents;
		QFile fileRead(filePath);
		if (fileRead.open(QIODevice::ReadOnly))
		{
			bool validLevelFound = true;
			levelData newLevelData;
			QTextStream qStream(&fileRead);
			while (!qStream.atEnd())
			{
				QString line = qStream.readLine();
				if (line.contains("::Id="))
				{
					newLevelData.id = extractSubstringInbetweenQt("::Id=", "::", line);
					newLevelData.creator = extractSubstringInbetweenQt("::CreatorName=", "::", line);
					newLevelData.name = extractSubstringInbetweenQt("::LevelName=", "::", line);
					newLevelData.difficulty = extractSubstringInbetweenQt("::LevelDifficulty=", "::", line).toInt();
					newLevelData.turnsInitial = extractSubstringInbetweenQt("::TurnsRemaining=", "::", line).toInt();
					newLevelData.turnsRemaining = newLevelData.turnsInitial;
				}
				else if (line.contains("::Gate=") && line.contains("::Key="))
				{
					// Need checks here to make sure number of Gate and number of Key is the same
					// Failing checks means NOT a valid level, leave out of level list

					QString gateData = extractSubstringInbetweenQt("::Gate=", "::", line);
					QString keyData = extractSubstringInbetweenQt("::Key=", "::", line);

					QStringList gateList = extractSubstringInbetweenQtLoopList("(", ")", gateData);
					QStringList keyList = extractSubstringInbetweenQtLoopList("(", ")", keyData);

					if (gateList.length() != keyList.length())
						validLevelFound = false;

					for (const auto& gate : gateList)
					{
						QStringList coords = gate.split(",", QString::SkipEmptyParts);
						newLevelData.gates.emplace_back
						(
							tokenImmobile
							{
								coords[0].toInt(),
								coords[1].toInt(),
								tokenImmobile::Type::GATE
							}
						);
					}
					for (const auto& key : keyList)
					{
						QStringList coords = key.split(",", QString::SkipEmptyParts);
						newLevelData.keys.emplace_back
						(
							tokenImmobile
							{
								coords[0].toInt(),
								coords[1].toInt(),
								tokenImmobile::Type::KEY
							}
						);
					}
				}
				else if (line.contains("::Player="))
				{
					QStringList coords = extractSubstringInbetweenQt("::Player=", "::", line).split(",", QString::SkipEmptyParts);
					newLevelData.players.emplace_back
					(
						tokenPlayer
						{
							coords[0].toInt(),
							coords[1].toInt()
						}
					);
				}
				else if (line.contains("::Pusher="))
				{
					QString pusherData = extractSubstringInbetweenQt("::Pusher=", "::", line);
					QStringList pusherList = extractSubstringInbetweenQtLoopList("(", ")", pusherData);
					for (const auto& pusher : pusherList)
					{
						QStringList components = pusher.split(",", QString::SkipEmptyParts);
						newLevelData.pushers.emplace_back
						(
							tokenPatroller
							{
								components[0].toInt(),
								components[1].toInt(),
								tokenPatroller::typeToEnum(components[2]),
								tokenPatroller::facingToEnum(components[3]),
								tokenPatroller::facingToEnum(components[3]),
								tokenPatroller::patrolDirToEnum(components[4]),
								components[5].toInt(),
								components[6].toInt(),
								components[7].toInt(),
								components[8].toInt()
							}
						);
					}
				}
				else if (line.contains("::Sucker="))
				{
					QString suckerData = extractSubstringInbetweenQt("::Sucker=", "::", line);
					QStringList suckerList = extractSubstringInbetweenQtLoopList("(", ")", suckerData);
					for (const auto& pusher : suckerList)
					{
						QStringList components = pusher.split(",", QString::SkipEmptyParts);
						newLevelData.suckers.emplace_back
						(
							tokenPatroller
							{
								components[0].toInt(),
								components[1].toInt(),
								tokenPatroller::typeToEnum(components[2]),
								tokenPatroller::facingToEnum(components[3]),
								tokenPatroller::facingToEnum(components[3]),
								tokenPatroller::patrolDirToEnum(components[4]),
								components[5].toInt(),
								components[6].toInt(),
								components[7].toInt(),
								components[8].toInt()
							}
						);
					}
				}
				else if (line.contains("::Util="))
				{
					QString utilData = extractSubstringInbetweenQt("::Util=", "::", line);
					QStringList utilList = extractSubstringInbetweenQtLoopList("(", ")", utilData);
					for (const auto& util : utilList)
					{
						// When loading a level for the first time, utils should always be INACTIVE.
						// For reusability of code and loading procedures, we look for state regardless.
						// This way for loading an in-progress level, varying state can be loaded as needed.
						QStringList components = util.split(",", QString::SkipEmptyParts);
						newLevelData.utils.emplace_back
						(
							tokenUtil
							{
								components[0].toInt(),
								components[1].toInt(),
								tokenUtil::typeToEnum(components[2]),
								tokenUtil::stateToEnum(components[3])
							}
						);
					}
				}
				else if (line.contains("::Block="))
				{
					QString blockData = extractSubstringInbetweenQt("::Block=", "::", line);
					QStringList blockList = extractSubstringInbetweenQtLoopList("(", ")", blockData);
					for (const auto& block : blockList)
					{
						QStringList coords = block.split(",", QString::SkipEmptyParts);
						newLevelData.blocks.emplace_back
						(
							tokenImmobile
							{
								coords[0].toInt(),
								coords[1].toInt(),
								tokenImmobile::Type::BLOCK
							}
						);
					}
				}
				else if (line.contains("::Hazard="))
				{
					QString hazardData = extractSubstringInbetweenQt("::Hazard=", "::", line);
					QStringList hazardList = extractSubstringInbetweenQtLoopList("(", ")", hazardData);
					for (const auto& hazard : hazardList)
					{
						QStringList coords = hazard.split(",", QString::SkipEmptyParts);
						newLevelData.hazards.emplace_back
						(
							tokenImmobile
							{
								coords[0].toInt(),
								coords[1].toInt(),
								tokenImmobile::Type::HAZARD
							}
						);
					}
				}
			}

			if (validLevelFound)
				levelsAll.emplace_back(std::move(newLevelData));
		}
		fileRead.close();
	}

	std::sort(levelsAll.begin(), levelsAll.end(), [&](const levelData &lhs, const levelData &rhs) {
		return lhs.difficulty < rhs.difficulty;
	});

	// Initialize base parameters for each level.
	// These are the default states that components get loaded in when a level is first loaded.
	for (auto& level : levelsAll)
	{
		levelSetToDefaults(level);
	}

	addCurrentLevelToScene();

	levelsAll[levelCurrent].players[pIndex].heldKeys = 0;
	levelsFound = levelsAll.size();
	levelsRemaining = levelsFound;

	uiGameplaySetToDefaults();

	turnOwner = TurnOwner::PLAYER;
}

// protected:

void GameplayScreen::keyReleaseEvent(QKeyEvent *event)
{
	if (event->isAutoRepeat())
	{
		event->ignore();
	}
	else
	{
		if (gameState == GameState::TITLE)
		{
			scene.get()->removeItem(splashItem.get());
			uiGameplayGroup->setVisible(true);
			updateWindowTitle();
			gameState = GameState::PLAYING;
		}
		else if (gameState == GameState::PLAYING)
		{
			if (event->key() == keybindMoveLeft
				|| event->key() == keybindMoveRight
				|| event->key() == keybindMoveUp
				|| event->key() == keybindMoveDown)
			{
				if (turnOwner == TurnOwner::PLAYER)
				{
					uiGameplayMessagesTextBox.get()->setText("");

					if (event->key() == keybindMoveLeft)
						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::LEFT;
					else if (event->key() == keybindMoveRight)
						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::RIGHT;
					else if (event->key() == keybindMoveUp)
						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::UP;
					else if (event->key() == keybindMoveDown)
						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::DOWN;

					if (!hitSolidObjectPlayerMoving())
					{
						const auto& pItem = levelsAll[levelCurrent].players[pIndex].item.get();
						switch (levelsAll[levelCurrent].players[pIndex].facing)
						{
						case (tokenPlayer::Facing::LEFT):
							levelsAll[levelCurrent].players[pIndex].item.get()->setPos
							(
								pItem->x() - (gridPieceSize * levelsAll[levelCurrent].players[pIndex].movementSpeed),
								pItem->y()
							);
							break;
						case (tokenPlayer::Facing::RIGHT):
							levelsAll[levelCurrent].players[pIndex].item.get()->setPos
							(
								pItem->x() + (gridPieceSize * levelsAll[levelCurrent].players[pIndex].movementSpeed),
								pItem->y()
							);
							break;
						case (tokenPlayer::Facing::UP):
							levelsAll[levelCurrent].players[pIndex].item.get()->setPos
							(
								pItem->x(),
								pItem->y() - (gridPieceSize * levelsAll[levelCurrent].players[pIndex].movementSpeed)
							);
							break;
						case (tokenPlayer::Facing::DOWN):
							levelsAll[levelCurrent].players[pIndex].item.get()->setPos
							(
								pItem->x(),
								pItem->y() + (gridPieceSize * levelsAll[levelCurrent].players[pIndex].movementSpeed)
							);
							break;
						}
						levelsAll[levelCurrent].players[pIndex].item.get()->setPixmap
						(
							facingToImg(levelsAll[levelCurrent].players[pIndex].facing)
						);
						levelsAll[levelCurrent].turnsRemaining--;
						uiGameplayUpdateStatCounterTurns();
						turnOwner = TurnOwner::PATROLLER;
					}

					if (turnOwner == TurnOwner::PATROLLER)
					{
						updatePositionPatrollers();
						suckInRange();

						if (allGatesOpened())
						{
							turnOwner = TurnOwner::NONE;
							levelSetComplete();
						}
						else if (levelsAll[levelCurrent].turnsRemaining <= 0)
						{
							turnOwner = TurnOwner::NONE;
							levelSetFailed();
						}
						else
							turnOwner = TurnOwner::PLAYER;
					}
				}
			}
			else if (event->key() == keybindPlacePusherUtil ||
				event->key() == keybindPlaceSuckerUtil)
			{
				if (turnOwner == TurnOwner::PLAYER)
				{
					uiGameplayMessagesTextBox.get()->setText("");

					auto& pushI = levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex;
					auto& suckI = levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex;

					if (event->key() == keybindPlacePusherUtil && pushI.size() > 0)
					{
						levelsAll[levelCurrent].utils[pushI[0]].item.get()->setPos
						(
							levelsAll[levelCurrent].players[pIndex].item.get()->x(),
							levelsAll[levelCurrent].players[pIndex].item.get()->y()
						);
						levelsAll[levelCurrent].utils[pushI[0]].stateModified = tokenUtil::State::ACTIVE;
						levelsAll[levelCurrent].utils[pushI[0]].item.get()->setPixmap
						(
							stateToImg(levelsAll[levelCurrent].utils[pushI[0]].stateModified, levelsAll[levelCurrent].utils[pushI[0]].type)
						);
						pushI.erase(pushI.begin() + 0);
						uiGameplayUpdateStatCounterPushers();
						uiGameplayMessagesTextBox->setText(uiGameplayMessagesTrapPusherDeployed);

						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::NEUTRAL;
						levelsAll[levelCurrent].players[pIndex].item.get()->setPixmap
						(
							facingToImg(levelsAll[levelCurrent].players[pIndex].facing)
						);

						turnOwner = TurnOwner::PATROLLER;
					}
					else if (event->key() == keybindPlaceSuckerUtil && suckI.size() > 0)
					{
						levelsAll[levelCurrent].utils[suckI[0]].item.get()->setPos
						(
							levelsAll[levelCurrent].players[pIndex].item.get()->x(),
							levelsAll[levelCurrent].players[pIndex].item.get()->y()
						);
						levelsAll[levelCurrent].utils[suckI[0]].stateModified = tokenUtil::State::ACTIVE;
						levelsAll[levelCurrent].utils[suckI[0]].item.get()->setPixmap
						(
							stateToImg(levelsAll[levelCurrent].utils[suckI[0]].stateModified, levelsAll[levelCurrent].utils[suckI[0]].type)
						);
						suckI.erase(suckI.begin() + 0);
						uiGameplayUpdateStatCounterSuckers();
						uiGameplayMessagesTextBox->setText(uiGameplayMessagesTrapSuckerDeployed);

						levelsAll[levelCurrent].players[pIndex].facing = tokenPlayer::Facing::NEUTRAL;
						levelsAll[levelCurrent].players[pIndex].item.get()->setPixmap
						(
							facingToImg(levelsAll[levelCurrent].players[pIndex].facing)
						);

						turnOwner = TurnOwner::PATROLLER;
					}

					if (turnOwner == TurnOwner::PATROLLER)
					{
						updatePositionPatrollers();
						suckInRange();

						if (allGatesOpened())
						{
							turnOwner = TurnOwner::NONE;
							levelSetComplete();
						}
						else if (levelsAll[levelCurrent].turnsRemaining <= 0)
						{
							turnOwner = TurnOwner::NONE;
							levelSetFailed();
						}
						else
							turnOwner = TurnOwner::PLAYER;
					}
				}
			}
			else if (event->key() == keybindOpenMenu)
			{
				if (turnOwner == TurnOwner::PLAYER)
				{
					gameState = GameState::PAUSED;
					uiMenuGroup.get()->setVisible(true);
				}
			}
		}
		else if (gameState == GameState::PAUSED)
		{
			if (event->key() == keybindOpenMenu)
			{
				uiMenuResumePlay();
			}
		}
		else if (gameState == GameState::KEYBINDING)
		{
			Qt::Key newKeybind = Qt::Key(event->key());

			// check if keybind is equal to an existing keybind that isn't the one being changed
			// if it is, set that keybind to nothing? or warn player.
			if (newKeybind == keybindMoveLeft ||
				newKeybind == keybindMoveRight ||
				newKeybind == keybindMoveUp ||
				newKeybind == keybindMoveDown ||
				newKeybind == keybindPlacePusherUtil ||
				newKeybind == keybindPlaceSuckerUtil ||
				newKeybind == keybindOpenMenu ||
				newKeybind == keybindNextLevel ||
				newKeybind == keybindResetLevel)
			{
				QMessageBox::information(this->parentWidget(),
					tr("Keybind In Use"),
					tr("That key is already bound to a command.")
				);
			}
			else if (newKeybind == Qt::Key_Control || newKeybind == Qt::Key_Shift)
			{
				QMessageBox::information(this->parentWidget(),
					tr("Keybind Invalid"),
					tr("Ctrl and Shift are not valid key input.")
				);
			}
			else
			{
				switch (keybindToModify)
				{
				case KeybindModifiable::MOVE_LEFT:
					keybindMoveLeft = newKeybind;
					uiGameplayKeymapBtnMoveLeft.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnMoveLeft->setText(QKeySequence(keybindMoveLeft).toString());
					break;
				case KeybindModifiable::MOVE_RIGHT:
					keybindMoveRight = newKeybind;
					uiGameplayKeymapBtnMoveRight.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnMoveRight->setText(QKeySequence(keybindMoveRight).toString());
					break;
				case KeybindModifiable::MOVE_UP:
					keybindMoveUp = newKeybind;
					uiGameplayKeymapBtnMoveUp.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnMoveUp->setText(QKeySequence(keybindMoveUp).toString());
					break;
				case KeybindModifiable::MOVE_DOWN:
					keybindMoveDown = newKeybind;
					uiGameplayKeymapBtnMoveDown.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnMoveDown->setText(QKeySequence(keybindMoveDown).toString());
					break;
				case KeybindModifiable::PLACE_PUSHER_UTIL:
					keybindPlacePusherUtil = newKeybind;
					uiGameplayKeymapBtnPlacePusherUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnPlacePusherUtil->setText(QKeySequence(keybindPlacePusherUtil).toString());
					break;
				case KeybindModifiable::PLACE_SUCKER_UTIL:
					keybindPlaceSuckerUtil = newKeybind;
					uiGameplayKeymapBtnPlaceSuckerUtil.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnPlaceSuckerUtil->setText(QKeySequence(keybindPlaceSuckerUtil).toString());
					break;
				case KeybindModifiable::OPEN_MENU:
					keybindOpenMenu = newKeybind;
					uiGameplayKeymapBtnOpenMenu.get()->setStyleSheet(uiGameplayKeymapBtnStyle);
					uiGameplayKeymapBtnOpenMenu->setText(QKeySequence(keybindOpenMenu).toString());
					break;
				}

				uiGameplayKeymapGroup.get()->setTitle(uiGameplayKeymapGroupTitleDefault);
				keybindToModify = KeybindModifiable::NONE;
				gameState = GameState::PLAYING;
			}
		}
		else if (gameState == GameState::LEVEL_COMPLETE)
		{
			if (event->key() == keybindNextLevel)
			{
				levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.clear();
				levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.clear();
				removeCurrentLevelFromScene();
				levelCurrent++;

				// We do a looping check on the next level to see if it's already set as complete.
				// This is to account for levels that are set to COMPLETE through a loaded save.
				// Normally, this would never be relevant, since levels are played in order and 
				// so you wouldn't hit one that is complete.
				// In fact, if file directory load order is consistent, it could be irrelevant even in save loading.
				// But we want to account for an edge case where a completed level comes after the current loaded one in a save.
				// Otherwise, player may have to complete the same levels twice, which makes Save functionality kinda pointless.
				while (levelsAll[levelCurrent].state == levelData::State::COMPLETE)
				{
					levelCurrent++;
				}

				qDebug() << "**DEBUG** Current Level Id: " + levelsAll[levelCurrent].id;

				addCurrentLevelToScene();
				scene.get()->removeItem(splashItem.get());
				uiGameplaySetToDefaults();
				uiGameplayGroup->setVisible(true);
				updateWindowTitle();
				gameState = GameState::PLAYING;
				turnOwner = TurnOwner::PLAYER;
			}
		}
		else if (gameState == GameState::LEVEL_FAILED)
		{
			if (event->key() == keybindResetLevel)
			{
				levelSetToDefaults(levelsAll[levelCurrent]);
				scene.get()->removeItem(splashItem.get());
				uiGameplaySetToDefaults();
				uiGameplayGroup->setVisible(true);
				gameState = GameState::PLAYING;
				turnOwner = TurnOwner::PLAYER;
			}
		}
	}
}

void GameplayScreen::prefSave()
{
	QFile fileWrite(appExecutablePath + "/config.txt");
	if (fileWrite.open(QIODevice::WriteOnly))
	{
		QTextStream qStream(&fileWrite);

		qStream << "KEYBINDS:\r\n"
			"keybindMoveLeft=" + QKeySequence(keybindMoveLeft).toString() + "\r\n"
			"keybindMoveRight=" + QKeySequence(keybindMoveRight).toString() + "\r\n"
			"keybindMoveUp=" + QKeySequence(keybindMoveUp).toString() + "\r\n"
			"keybindMoveDown=" + QKeySequence(keybindMoveDown).toString() + "\r\n"
			"keybindPlacePusherUtil=" + QKeySequence(keybindPlacePusherUtil).toString() + "\r\n"
			"keybindPlaceSuckerUtil=" + QKeySequence(keybindPlaceSuckerUtil).toString() + "\r\n"
			"keybindOpenMenu=" + QKeySequence(keybindOpenMenu).toString() + "\r\n"
			;
		fileWrite.close();
	}
}

// private:

void GameplayScreen::prefLoad()
{
	QFile fileRead(appExecutablePath + "/config.txt");
	if (fileRead.open(QIODevice::ReadOnly))
	{
		QTextStream qStream(&fileRead);
		while (!qStream.atEnd())
		{
			QString line = qStream.readLine();
			if (line.contains("keybindMoveLeft"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindMoveLeft = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindMoveRight"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindMoveRight = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindMoveUp"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindMoveUp = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindMoveDown"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindMoveDown = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindPlacePusherUtil"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindPlacePusherUtil = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindPlaceSuckerUtil"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindPlaceSuckerUtil = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
			else if (line.contains("keybindOpenMenu"))
			{
				QString newKey = extractSubstringInbetweenQt("=", "", line);
				if (!newKey.isEmpty())
					keybindOpenMenu = Qt::Key(QKeySequence::fromString(newKey)[0]);
			}
		}
		fileRead.close();
	}
}

bool GameplayScreen::hitSolidObjectPlayerMoving()
{
	// Areas beyond grid edges are solid objects
	// Enemy and player are solid objects
	// Gate is considered solid, unless a player with a key is hitting it
	// Keys are not solid for player, and are solid for enemies

	const auto& pItem = levelsAll[levelCurrent].players[pIndex].item.get();
	const auto& pAtIndex = levelsAll[levelCurrent].players[pIndex];

	int nextY;
	int nextX;

	switch (levelsAll[levelCurrent].players[pIndex].facing)
	{
	case (tokenPlayer::Facing::UP):
		nextY = pItem->y() - (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY < gridBoundUp)
		{
			return true;
		}
		break;
	case (tokenPlayer::Facing::DOWN):
		nextY = pItem->y() + (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY > gridBoundDown)
		{
			return true;
		}
		break;
	case (tokenPlayer::Facing::LEFT):
		nextY = pItem->y();
		nextX = pItem->x() - (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX < gridBoundLeft)
		{
			return true;
		}
		break;
	case (tokenPlayer::Facing::RIGHT):
		nextY = pItem->y();
		nextX = pItem->x() + (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX > gridBoundRight)
		{
			return true;
		}
		break;
	}


	if (hitImmobileObject(levelsAll[levelCurrent].blocks, nextY, nextX))
	{
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesObstacle);
		return true;
	}
	else if (hitImmobileObject(levelsAll[levelCurrent].hazards, nextY, nextX))
	{
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesHazard);
		return true;
	}
	else if (hitEnemy(levelsAll[levelCurrent].suckers, nextY, nextX))
	{
		return true;
	}
	else if (hitEnemy(levelsAll[levelCurrent].pushers, nextY, nextX))
	{
		for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
		{
			knockbackPlayerMoving();
		}
		hazardHitCheck();
		turnOwner = TurnOwner::PATROLLER;
		return true;
	}
	else if (hitEnemy(levelsAll[levelCurrent].suckers, nextY, nextX))
	{
		turnOwner = TurnOwner::PATROLLER;
		return true;
	}
	else if (hitUtil(nextY, nextX))
	{
		return false;
	}
	else if (hitImmobileObject(levelsAll[levelCurrent].gates, nextY, nextX))
	{
		if (levelsAll[levelCurrent].players[pIndex].heldKeys > 0)
		{
			hitImmobileObjectAndDelete(levelsAll[levelCurrent].gates, nextY, nextX);
			levelsAll[levelCurrent].players[pIndex].heldKeys--;
			uiGameplayUpdateStatCounterKeys();
			return false;
		}
		else
		{
			uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyNeeded);
			return true;
		}
	}
	else if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].keys, nextY, nextX))
	{
		levelsAll[levelCurrent].players[pIndex].heldKeys++;
		uiGameplayUpdateStatCounterKeys();
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyObtained);
		return false;
	}
	else
	{
		return false;
	}
}

bool GameplayScreen::hitImmobileObject(const std::vector<tokenImmobile>& immobiles, const int playerNextY, const int playerNextX)
{
	const int numImmobiles = immobiles.size();
	for (int i = 0; i < numImmobiles; i++)
	{
		if (playerNextY == immobiles[i].item.get()->y()
			&& playerNextX == immobiles[i].item.get()->x()
			&& immobiles[i].state != tokenImmobile::State::INVISIBLE)
		{
			return true;
		}
	}
	return false;
}

bool GameplayScreen::hitImmobileObjectAndDelete(std::vector<tokenImmobile>& immobiles, const int playerNextY, const int playerNextX)
{
	const int numImmobiles = immobiles.size();
	for (int i = 0; i < numImmobiles; i++)
	{
		if (playerNextY == immobiles[i].item.get()->y()
			&& playerNextX == immobiles[i].item.get()->x()
			&& immobiles[i].state == tokenImmobile::State::ACTIVE)
		{
			if (immobiles[i].type == tokenImmobile::Type::KEY)
				immobiles[i].state = tokenImmobile::State::HELD;
			else
				immobiles[i].state = tokenImmobile::State::INVISIBLE;
			immobiles[i].item.get()->setPixmap
			(
				stateToImg(immobiles[i].state, immobiles[i].type)
			);
			return true;
		}
	}
	return false;
}

bool GameplayScreen::hitEnemy(const std::vector<tokenPatroller>& patrollers, const int playerNextY, const int playerNextX)
{
	const int tokens = patrollers.size();
	for (int i = 0; i < tokens; i++)
	{
		if (playerNextY == patrollers[i].item.get()->y() && playerNextX == patrollers[i].item.get()->x())
		{
			return true;
		}
	}
	return false;
}

bool GameplayScreen::hitUtil(const int playerNextY, const int playerNextX)
{
	const int numUtils = levelsAll[levelCurrent].utils.size();
	for (int i = 0; i < numUtils; i++)
	{
		if (playerNextY == levelsAll[levelCurrent].utils[i].item.get()->y()
			&& playerNextX == levelsAll[levelCurrent].utils[i].item.get()->x())
		{
			if (levelsAll[levelCurrent].utils[i].stateModified != tokenUtil::State::HELD)
			{
				if (levelsAll[levelCurrent].utils[i].type == tokenUtil::Type::PUSHER)
				{
					levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.push_back(i);
					uiGameplayUpdateStatCounterPushers();
					uiGameplayMessagesTextBox->setText(uiGameplayMessagesTrapPusherObtained);
				}
				else if (levelsAll[levelCurrent].utils[i].type == tokenUtil::Type::SUCKER)
				{
					levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.push_back(i);
					uiGameplayUpdateStatCounterSuckers();
					uiGameplayMessagesTextBox->setText(uiGameplayMessagesTrapSuckerObtained);
				}
				levelsAll[levelCurrent].utils[i].stateModified = tokenUtil::State::HELD;
				levelsAll[levelCurrent].utils[i].item.get()->setPixmap
				(
					stateToImg(levelsAll[levelCurrent].utils[i].stateModified, levelsAll[levelCurrent].utils[i].type)
				);

				return true;
			}
		}
	}
	return false;
}

void GameplayScreen::knockbackPlayerMoving()
{
	// If player is moving into enemy, we knockback player in the opposite direction

	const auto& pItem = levelsAll[levelCurrent].players[pIndex].item.get();
	const auto& pAtIndex = levelsAll[levelCurrent].players[pIndex];

	int nextY;
	int nextX;

	switch (levelsAll[levelCurrent].players[pIndex].facing)
	{
	case (tokenPlayer::Facing::UP):
		nextY = pItem->y() + (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY < gridBoundDown)
		{
			pItem->setPos(nextX, nextY);
		}
		else
		{
			pItem->setPos(nextX, gridBoundDown - gridPieceSize + (gridPieceSize / 4));
		}
		break;
	case (tokenPlayer::Facing::DOWN):
		nextY = pItem->y() - (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY > gridBoundUp)
		{
			pItem->setPos(nextX, nextY);
		}
		else
		{
			pItem->setPos(nextX, gridBoundUp + (gridPieceSize / 4));
		}
		break;
	case (tokenPlayer::Facing::LEFT):
		nextY = pItem->y();
		nextX = pItem->x() + (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX < gridBoundRight)
		{
			pItem->setPos(nextX, nextY);
		}
		else
		{
			pItem->setPos(gridBoundRight - gridPieceSize + (gridPieceSize / 4), nextY);
		}
		break;
	case (tokenPlayer::Facing::RIGHT):
		nextY = pItem->y();
		nextX = pItem->x() - (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX > gridBoundLeft)
		{
			pItem->setPos(nextX, nextY);
		}
		else
		{
			pItem->setPos(gridBoundLeft + (gridPieceSize / 4), nextY);
		}
		break;
	}

	nextY = pItem->y();
	nextX = pItem->x();

	if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].blocks, nextY, nextX)
		|| hitEnemy(levelsAll[levelCurrent].pushers, nextY, nextX)
		|| hitEnemy(levelsAll[levelCurrent].suckers, nextY, nextX))
	{
		return;
	}
	else if (hitImmobileObject(levelsAll[levelCurrent].gates, nextY, nextX))
	{
		if (levelsAll[levelCurrent].players[pIndex].heldKeys > 0)
		{
			hitImmobileObjectAndDelete(levelsAll[levelCurrent].gates, nextY, nextX);
			levelsAll[levelCurrent].players[pIndex].heldKeys--;
			uiGameplayUpdateStatCounterKeys();
			return;
		}
		else
		{
			uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyNeeded);
			return;
		}
	}
	else if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].keys, nextY, nextX))
	{
		levelsAll[levelCurrent].players[pIndex].heldKeys++;
		uiGameplayUpdateStatCounterKeys();
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyObtained);
		return;
	}
}

void GameplayScreen::updatePositionPatrollers()
{
	const int numPushers = levelsAll[levelCurrent].pushers.size();
	for (int i = 0; i < numPushers; i++)
	{
		updatePositionPatrollerMoves(levelsAll[levelCurrent].pushers, i);
	}

	const int numSuckers = levelsAll[levelCurrent].suckers.size();
	for (int i = 0; i < numSuckers; i++)
	{
		updatePositionPatrollerMoves(levelsAll[levelCurrent].suckers, i);
	}
}

void GameplayScreen::updatePositionPatrollerMoves(std::vector<tokenPatroller>& patrollers, const int enemyNum)
{
	const auto& eItem = patrollers[enemyNum].item.get();

	switch (patrollers[enemyNum].patrolDir)
	{
	case tokenPatroller::PatrolDir::VERTICAL:
	{
		switch (patrollers[enemyNum].facing)
		{
		case tokenPatroller::Facing::UP:
			if (patrollers[enemyNum].item.get()->y() - gridPieceSize
				< patrollers[enemyNum].initialY - (patrollers[enemyNum].patrolBoundUp * gridPieceSize))
			{
				patrollers[enemyNum].facing = tokenPatroller::Facing::DOWN;
				patrollers[enemyNum].item.get()->setPixmap
				(
					facingToImg(patrollers[enemyNum].facing, patrollers[enemyNum].type)
				);
			}
			else
			{
				int nextY = eItem->y() - (gridPieceSize * patrollers[enemyNum].movementSpeed);
				int nextX = eItem->x();
				if (patrollerHitTrapPush(patrollers, enemyNum, nextY, nextX))
				{
					for (int i = 0; i < 2; i++)
					{
						knockbackHitTrap(patrollers, enemyNum);
					}
				}
				else
				{
					eItem->setPos(eItem->x(), nextY);
					suckInHitTrap(patrollers, enemyNum);
					if (hitPlayer(patrollers, enemyNum))
					{
						if (patrollers[enemyNum].type == tokenPatroller::Type::PUSHER)
						{
							for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
							{
								knockbackEnemyMoving(enemyNum);
							}
							hazardHitCheck();
						}
					}
				}
			}
			break;
		case tokenPatroller::Facing::DOWN:
			if (eItem->y() + gridPieceSize
							> patrollers[enemyNum].initialY + (patrollers[enemyNum].patrolBoundDown * gridPieceSize))
			{
				patrollers[enemyNum].facing = tokenPatroller::Facing::UP;
				patrollers[enemyNum].item.get()->setPixmap
				(
					facingToImg(patrollers[enemyNum].facing, patrollers[enemyNum].type)
				);
			}
			else
			{
				int nextY = eItem->y() + (gridPieceSize * patrollers[enemyNum].movementSpeed);
				int nextX = eItem->x();
				if (patrollerHitTrapPush(patrollers, enemyNum, nextY, nextX))
				{
					for (int i = 0; i < 2; i++)
					{
						knockbackHitTrap(patrollers, enemyNum);
					}
				}
				else
				{
					eItem->setPos(eItem->x(), nextY);
					suckInHitTrap(patrollers, enemyNum);
					if (hitPlayer(patrollers, enemyNum))
					{
						if (patrollers[enemyNum].type == tokenPatroller::Type::PUSHER)
						{
							for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
							{
								knockbackEnemyMoving(enemyNum);
							}
							hazardHitCheck();
						}
					}
				}
			}
			break;
		}
	}
	break;
	case tokenPatroller::PatrolDir::HORIZONTAL:
	{
		switch (patrollers[enemyNum].facing)
		{
		case tokenPatroller::Facing::LEFT:
			if (eItem->x() - gridPieceSize
				< patrollers[enemyNum].initialX - (patrollers[enemyNum].patrolBoundLeft * gridPieceSize))
			{
				patrollers[enemyNum].facing = tokenPatroller::Facing::RIGHT;
				patrollers[enemyNum].item.get()->setPixmap
				(
					facingToImg(patrollers[enemyNum].facing, patrollers[enemyNum].type)
				);
			}
			else
			{
				int nextY = eItem->y();
				int nextX = eItem->x() - (gridPieceSize * patrollers[enemyNum].movementSpeed);
				if (patrollerHitTrapPush(patrollers, enemyNum, nextY, nextX))
				{
					for (int i = 0; i < 2; i++)
					{
						knockbackHitTrap(patrollers, enemyNum);
					}
				}
				else
				{
					eItem->setPos(nextX, eItem->y());
					suckInHitTrap(patrollers, enemyNum);
					if (hitPlayer(patrollers, enemyNum))
					{
						if (patrollers[enemyNum].type == tokenPatroller::Type::PUSHER)
						{
							for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
							{
								knockbackEnemyMoving(enemyNum);
							}
							hazardHitCheck();
						}
					}
				}
			}
			break;
		case tokenPatroller::Facing::RIGHT:
			if (eItem->x() + gridPieceSize
							> patrollers[enemyNum].initialX + (patrollers[enemyNum].patrolBoundRight * gridPieceSize))
			{
				patrollers[enemyNum].facing = tokenPatroller::Facing::LEFT;
				patrollers[enemyNum].item.get()->setPixmap
				(
					facingToImg(patrollers[enemyNum].facing, patrollers[enemyNum].type)
				);
			}
			else
			{
				int nextY = eItem->y();
				int nextX = eItem->x() + (gridPieceSize * patrollers[enemyNum].movementSpeed);
				if (patrollerHitTrapPush(patrollers, enemyNum, nextY, nextX))
				{
					for (int i = 0; i < 2; i++)
					{
						knockbackHitTrap(patrollers, enemyNum);
					}
				}
				else
				{
					eItem->setPos(nextX, eItem->y());
					suckInHitTrap(patrollers, enemyNum);
					if (hitPlayer(patrollers, enemyNum))
					{
						if (patrollers[enemyNum].type == tokenPatroller::Type::PUSHER)
						{
							for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
							{
								knockbackEnemyMoving(enemyNum);
							}
							hazardHitCheck();
						}
					}
				}
			}
			break;
		}
	}
	break;
	}
}

void GameplayScreen::knockbackEnemyMoving(int enemyNum)
{
	// If enemy is moving into player, we knockback player in the direction enemy is moving

	const auto& pItem = levelsAll[levelCurrent].players[pIndex].item.get();
	const auto& pAtIndex = levelsAll[levelCurrent].players[pIndex];

	int nextY;
	int nextX;

	switch (levelsAll[levelCurrent].pushers[enemyNum].facing)
	{
	case (tokenPatroller::Facing::UP):
		nextY = pItem->y() - (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY > gridBoundUp)
		{
			pItem->setPos(pItem->x(), nextY);
		}
		else
		{
			pItem->setPos(pItem->x(), gridBoundUp + (gridPieceSize / 4));
		}
		break;
	case (tokenPatroller::Facing::DOWN):
		nextY = pItem->y() + (gridPieceSize * pAtIndex.movementSpeed);
		nextX = pItem->x();
		if (nextY < gridBoundDown)
		{
			pItem->setPos(pItem->x(), nextY);
		}
		else
		{
			pItem->setPos(pItem->x(), gridBoundDown - gridPieceSize + (gridPieceSize / 4));
		}
		break;
	case (tokenPatroller::Facing::LEFT):
		nextY = pItem->y();
		nextX = pItem->x() - (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX > gridBoundLeft)
		{
			pItem->setPos(nextX, pItem->y());
		}
		else
		{
			pItem->setPos(gridBoundLeft + (gridPieceSize / 4), pItem->y());
		}
		break;
	case (tokenPatroller::Facing::RIGHT):
		nextY = pItem->y();
		nextX = pItem->x() + (gridPieceSize * pAtIndex.movementSpeed);
		if (nextX < gridBoundRight)
		{
			pItem->setPos(nextX, pItem->y());
		}
		else
		{
			pItem->setPos(gridBoundRight - gridPieceSize + (gridPieceSize / 4), pItem->y());
		}
		break;
	}

	nextY = pItem->y();
	nextX = pItem->x();

	if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].blocks, nextY, nextX))
	{
		return;
	}
	else if (hitImmobileObject(levelsAll[levelCurrent].gates, nextY, nextX))
	{
		if (pAtIndex.heldKeys > 0)
		{
			hitImmobileObjectAndDelete(levelsAll[levelCurrent].gates, nextY, nextX);
			levelsAll[levelCurrent].players[pIndex].heldKeys--;
			uiGameplayUpdateStatCounterKeys();
			return;
		}
		else
		{
			uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyNeeded);
			return;
		}
	}
	else if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].keys, nextY, nextX))
	{
		levelsAll[levelCurrent].players[pIndex].heldKeys++;
		uiGameplayUpdateStatCounterKeys();
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyObtained);
		return;
	}
	else
	{
		return;
	}
}

bool GameplayScreen::patrollerHitTrapPush(const std::vector<tokenPatroller>& patrollers, const int enemyNum, const int patrollerNextY, const int patrollerNextX)
{
	const int tokens = levelsAll[levelCurrent].utils.size();
	for (int i = 0; i < tokens; i++)
	{
		if (patrollerNextY == levelsAll[levelCurrent].utils[i].item.get()->y()
			&& patrollerNextX == levelsAll[levelCurrent].utils[i].item.get()->x())
		{
			if (levelsAll[levelCurrent].utils[i].type == tokenUtil::Type::PUSHER)
			{
				if (levelsAll[levelCurrent].utils[i].stateModified == tokenUtil::State::ACTIVE)
				{
					return true;
				}
			}
		}
	}
	return false;
}

void GameplayScreen::knockbackHitTrap(std::vector<tokenPatroller>& patrollers, const int enemyNum)
{
	// Logistics of this feature:
	// Follow the same logic as player knockback (e.g. check for knockback hit BEFORE enemy is moved)
	// If there's a collision with a knockback trap, knockback patroller one square (do this twice)

	// If patroller is moving into knockback trap, we knockback patroller in the opposite direction

	const auto& eItem = patrollers[enemyNum].item.get();

	int nextY;
	int nextX;

	switch (patrollers[enemyNum].facing)
	{
	case (tokenPatroller::Facing::UP):
		nextY = eItem->y() + (gridPieceSize * patrollers[enemyNum].movementSpeed);
		nextX = eItem->x();
		if (nextY < gridBoundDown)
		{
			eItem->setPos(eItem->x(), nextY);
		}
		else
		{
			eItem->setPos(eItem->x(), gridBoundDown - gridPieceSize + (gridPieceSize / 4));
		}
		break;
	case (tokenPatroller::Facing::DOWN):
		nextY = eItem->y() - (gridPieceSize * patrollers[enemyNum].movementSpeed);
		nextX = eItem->x();
		if (nextY > gridBoundUp)
		{
			eItem->setPos(eItem->x(), nextY);
		}
		else
		{
			eItem->setPos(eItem->x(), gridBoundUp + (gridPieceSize / 4));
		}
		break;
	case (tokenPatroller::Facing::LEFT):
		nextY = eItem->y();
		nextX = eItem->x() + (gridPieceSize * patrollers[enemyNum].movementSpeed);
		if (nextX < gridBoundRight)
		{
			eItem->setPos(nextX, eItem->y());
		}
		else
		{
			eItem->setPos(gridBoundRight - gridPieceSize + (gridPieceSize / 4), eItem->y());
		}
		break;
	case (tokenPatroller::Facing::RIGHT):
		nextY = eItem->y();
		nextX = eItem->x() - (gridPieceSize * patrollers[enemyNum].movementSpeed);
		if (nextX > gridBoundLeft)
		{
			eItem->setPos(nextX, eItem->y());
		}
		else
		{
			eItem->setPos(gridBoundLeft + (gridPieceSize / 4), eItem->y());
		}
		break;
	}

	nextY = eItem->y();
	nextX = eItem->x();

	if (hitPlayer(patrollers, enemyNum))
	{
		if (patrollers[enemyNum].type == tokenPatroller::Type::PUSHER)
		{
			for (int i = 0; i < levelsAll[levelCurrent].players[pIndex].knockbackAmount; i++)
			{
				knockbackPlayerMoving();
			}
		}
	}
}

bool GameplayScreen::hitPlayer(const std::vector<tokenPatroller>& patrollers, const int enemyNum)
{
	if (patrollers[enemyNum].item.get()->y() == levelsAll[levelCurrent].players[pIndex].item.get()->y()
		&& patrollers[enemyNum].item.get()->x() == levelsAll[levelCurrent].players[pIndex].item.get()->x())
	{
		return true;
	}
	else
	{
		return false;
	}
}

void GameplayScreen::suckInHitTrap(std::vector<tokenPatroller>& patrollers, const int enemyNum)
{
	const auto& eItem = patrollers[enemyNum].item.get();

	const int suckRange = 2;
	const int numSuckers = levelsAll[levelCurrent].utils.size();
	for (int i = 0; i < numSuckers; i++)
	{
		const auto& uAtIndex = levelsAll[levelCurrent].utils[i];

		if (uAtIndex.type == tokenUtil::Type::SUCKER
			&& uAtIndex.stateModified == tokenUtil::State::ACTIVE)
		{
			if (eItem->y() == uAtIndex.item.get()->y())
			{
				if (eItem->x() < uAtIndex.item.get()->x())
				{
					// player is to the LEFT of sucker
					if (abs(uAtIndex.item.get()->x() - eItem->x()) / gridPieceSize == suckRange)
					{
						// move player one to the RIGHT
						eItem->setPos(eItem->x() + patrollers[enemyNum].movementSpeed * gridPieceSize, eItem->y());
						suckInHitCheck();
						return;
					}
				}
				else if (eItem->x() > uAtIndex.item.get()->x())
				{
					// player is to the RIGHT of sucker
					if (abs(uAtIndex.item.get()->x() - eItem->x()) / gridPieceSize == suckRange)
					{
						// move player one to the LEFT
						eItem->setPos(eItem->x() - patrollers[enemyNum].movementSpeed * gridPieceSize, eItem->y());
						suckInHitCheck();
						return;
					}
				}
			}
			else if (eItem->x() == uAtIndex.item.get()->x())
			{
				if (eItem->y() < uAtIndex.item.get()->y())
				{
					// player is UP of sucker
					if (abs(uAtIndex.item.get()->y() - eItem->y()) / gridPieceSize == suckRange)
					{
						// move player one DOWN
						eItem->setPos(eItem->x(), eItem->y() + patrollers[enemyNum].movementSpeed * gridPieceSize);
						suckInHitCheck();
						return;
					}
				}
				else if (eItem->y() > uAtIndex.item.get()->y())
				{
					// player is DOWN of sucker
					if (abs(uAtIndex.item.get()->y() - eItem->y()) / gridPieceSize == suckRange)
					{
						// move player one UP
						eItem->setPos(eItem->x(), eItem->y() - patrollers[enemyNum].movementSpeed * gridPieceSize);
						suckInHitCheck();
						return;
					}
				}
			}
		}
	}
}

void GameplayScreen::suckInHitCheck()
{
	const int nextY = levelsAll[levelCurrent].players[pIndex].item.get()->y();
	const int nextX = levelsAll[levelCurrent].players[pIndex].item.get()->x();

	if (hitEnemy(levelsAll[levelCurrent].pushers, nextY, nextX)
		|| hitEnemy(levelsAll[levelCurrent].suckers, nextY, nextX))
	{
		return;
	}
	else if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].blocks, nextY, nextX))
	{
		return;
	}
	else if (hitImmobileObject(levelsAll[levelCurrent].gates, nextY, nextX))
	{
		if (levelsAll[levelCurrent].players[pIndex].heldKeys > 0)
		{
			hitImmobileObjectAndDelete(levelsAll[levelCurrent].gates, nextY, nextX);
			levelsAll[levelCurrent].players[pIndex].heldKeys--;
			uiGameplayUpdateStatCounterKeys();
			return;
		}
		else
		{
			uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyNeeded);
			return;
		}
	}
	else if (hitImmobileObjectAndDelete(levelsAll[levelCurrent].keys, nextY, nextX))
	{
		levelsAll[levelCurrent].players[pIndex].heldKeys++;
		uiGameplayUpdateStatCounterKeys();
		uiGameplayMessagesTextBox.get()->setText(uiGameplayMessagesKeyObtained);
		return;
	}
}

void GameplayScreen::suckInRange()
{
	const auto& pItem = levelsAll[levelCurrent].players[pIndex].item.get();
	const auto& pAtIndex = levelsAll[levelCurrent].players[pIndex];

	const int suckRange = 2;
	const int numSuckers = levelsAll[levelCurrent].suckers.size();
	for (int i = 0; i < numSuckers; i++)
	{
		const auto& sItem = levelsAll[levelCurrent].suckers[i].item.get();

		if (pItem->y() == sItem->y())
		{
			if (pItem->x() < sItem->x())
			{
				// player is to the LEFT of sucker
				if (abs(sItem->x() - pItem->x()) / gridPieceSize == suckRange)
				{
					// move player one to the RIGHT
					pItem->setPos(pItem->x() + pAtIndex.movementSpeed * gridPieceSize, pItem->y());
					suckInHitCheck();
					return;
				}
			}
			else if (pItem->x() > sItem->x())
			{
				// player is to the RIGHT of sucker
				if (abs(sItem->x() - pItem->x()) / gridPieceSize == suckRange)
				{
					// move player one to the LEFT
					pItem->setPos(pItem->x() - pAtIndex.movementSpeed * gridPieceSize, pItem->y());
					suckInHitCheck();
					return;
				}
			}
		}
		else if (pItem->x() == sItem->x())
		{
			if (pItem->y() < sItem->y())
			{
				// player is UP of sucker
				if (abs(sItem->y() - pItem->y()) / gridPieceSize == suckRange)
				{
					// move player one DOWN
					pItem->setPos(pItem->x(), pItem->y() + pAtIndex.movementSpeed * gridPieceSize);
					suckInHitCheck();
					return;
				}
			}
			else if (pItem->y() > sItem->y())
			{
				// player is DOWN of sucker
				if (abs(sItem->y() - pItem->y()) / gridPieceSize == suckRange)
				{
					// move player one UP
					pItem->setPos(pItem->x(), pItem->y() - pAtIndex.movementSpeed * gridPieceSize);
					suckInHitCheck();
					return;
				}
			}
		}
	}
}

void GameplayScreen::hazardHitCheck()
{
	// Hazards are instant level-ending penalty if you land on them.
	// This gives a reason in design for player to be more careful about how far they are getting pushed
	// by pushers. Pushed two squares could get them past a hazard. Pushed one square right into it.
	// (expands on what kind of challenges you can present in level design, in other words)
	for (const auto& hazard : levelsAll[levelCurrent].hazards)
	{
		if (levelsAll[levelCurrent].players[pIndex].item.get()->x() == hazard.item.get()->x() &&
			levelsAll[levelCurrent].players[pIndex].item.get()->y() == hazard.item.get()->y())
		{
			levelsAll[levelCurrent].turnsRemaining = 0;
			return;
		}
	}
}

void GameplayScreen::levelSetFailed()
{
	uiGameplayGroup->setVisible(false);
	gameState = GameState::LEVEL_FAILED;
	splashItem.get()->setPixmap(imgSplashLevelFailed);
	scene.get()->addItem(splashItem.get());
}

void GameplayScreen::levelSetToDefaults(levelData& level)
{
	levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.clear();
	levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.clear();
	levelsAll[levelCurrent].turnsRemaining = levelsAll[levelCurrent].turnsInitial;
	for (auto& key : level.keys)
	{
		key.state = tokenImmobile::State::ACTIVE;
		key.item.get()->setPixmap
		(
			stateToImg(key.state, key.type)
		);
		key.item.get()->setPos(key.initialX, key.initialY);
		key.item.get()->setZValue(tokenImmobileZ);
		qDebug() << "key: " << key.initialX;
		qDebug() << "key: " << key.initialY;
	}
	for (auto& gate : level.gates)
	{
		gate.state = tokenImmobile::State::ACTIVE;
		gate.item.get()->setPixmap
		(
			stateToImg(gate.state, gate.type)
		);
		gate.item.get()->setPos(gate.initialX, gate.initialY);
		gate.item.get()->setZValue(tokenImmobileZ);
		qDebug() << "gate: " << gate.initialX;
		qDebug() << "gate: " << gate.initialY;
	}
	for (auto& player : level.players)
	{
		player.heldKeys = 0;
		player.item.get()->setPixmap
		(
			facingToImg(player.facing)
		);
		player.item.get()->setPos(player.initialX, player.initialY);
		player.item.get()->setZValue(tokenMobileZ);
		qDebug() << "player: " << player.initialX;
		qDebug() << "player: " << player.initialY;
	}
	for (auto& pusher : level.pushers)
	{
		pusher.facing = pusher.facingInitial;
		pusher.item.get()->setPixmap
		(
			facingToImg(pusher.facing, pusher.type)
		);
		pusher.item.get()->setPos(pusher.initialX, pusher.initialY);
		pusher.item.get()->setZValue(tokenMobileZ);
		qDebug() << "pusher: " << pusher.initialX;
		qDebug() << "pusher: " << pusher.initialY;
	}
	for (auto& sucker : level.suckers)
	{
		sucker.facing = sucker.facingInitial;
		sucker.item.get()->setPixmap
		(
			facingToImg(sucker.facing, sucker.type)
		);
		sucker.item.get()->setPos(sucker.initialX, sucker.initialY);
		sucker.item.get()->setZValue(tokenMobileZ);
		qDebug() << "sucker: " << sucker.initialX;
		qDebug() << "sucker: " << sucker.initialY;
	}
	for (auto& util : level.utils)
	{
		util.stateModified = util.stateBase;
		util.item.get()->setPixmap
		(
			stateToImg(util.stateModified, util.type)
		);
		util.item.get()->setPos(util.initialX, util.initialY);
		util.item.get()->setZValue(tokenImmobileZ);
		qDebug() << "util: " << util.initialX;
		qDebug() << "util: " << util.initialY;
	}
	for (auto& block : level.blocks)
	{
		block.state = tokenImmobile::State::ACTIVE;
		block.item.get()->setPixmap
		(
			stateToImg(block.state, block.type)
		);
		block.item.get()->setPos(block.initialX, block.initialY);
		block.item.get()->setZValue(tokenImmobileZ);
		qDebug() << block.initialX;
		qDebug() << block.initialY;
	}
	for (auto& hazard : level.hazards)
	{
		hazard.state = tokenImmobile::State::ACTIVE;
		hazard.item.get()->setPixmap
		(
			stateToImg(hazard.state, hazard.type)
		);
		hazard.item.get()->setPos(hazard.initialX, hazard.initialY);
		hazard.item.get()->setZValue(tokenImmobileZ);
		qDebug() << hazard.initialX;
		qDebug() << hazard.initialY;
	}
}

void GameplayScreen::levelSetComplete()
{
	uiGameplayGroup->setVisible(false);
	levelsComplete++;
	levelsRemaining--;
	levelsAll[levelCurrent].state = levelData::State::COMPLETE;

	if (levelsRemaining > 0)
	{
		gameState = GameState::LEVEL_COMPLETE;
		splashItem.get()->setPixmap(imgSplashLevelComplete);
	}
	else
	{
		gameState = GameState::LEVEL_ALL_DONE;
		splashItem.get()->setPixmap(imgSplashLevelAllDone);
	}
	scene.get()->addItem(splashItem.get());
}

int GameplayScreen::levelLoadValidateId(QFile &file)
{
	QTextStream qStream(&file);
	QString line = qStream.readLine();
	int levelPos = -1;
	if (line.contains("::Id="))
	{
		QString idStr = extractSubstringInbetweenQt("::Id=", "::", line);
		return levelFoundInListAtPos(idStr);
	}
	return levelPos;
}

int GameplayScreen::levelFoundInListAtPos(const QString &id)
{
	const int levelsAllSize = levelsAll.size();
	for (int i = 0; i < levelsAllSize; i++)
	{
		if (levelsAll[i].id == id)
			return i;
	}
	return -1;
}

int GameplayScreen::levelFoundInList(const QString &id)
{
	for (const auto& level : levelsAll)
	{
		if (level.id == id)
			return true;
	}
	return false;
}

bool GameplayScreen::allGatesOpened()
{
	for (const auto& gate : levelsAll[levelCurrent].gates)
	{
		if (gate.state != tokenImmobile::State::INVISIBLE)
			return false;
	}
	return true;
}

void GameplayScreen::addCurrentLevelToScene()
{
	for (const auto& key : levelsAll[levelCurrent].keys)
	{
		scene.get()->addItem(key.item.get());
	}
	for (const auto& gate : levelsAll[levelCurrent].gates)
	{
		scene.get()->addItem(gate.item.get());
	}
	for (const auto& player : levelsAll[levelCurrent].players)
	{
		scene.get()->addItem(player.item.get());
	}
	for (const auto& pusher : levelsAll[levelCurrent].pushers)
	{
		scene.get()->addItem(pusher.item.get());
	}
	for (const auto& sucker : levelsAll[levelCurrent].suckers)
	{
		scene.get()->addItem(sucker.item.get());
	}
	for (const auto& util : levelsAll[levelCurrent].utils)
	{
		scene.get()->addItem(util.item.get());
	}
	for (const auto& block : levelsAll[levelCurrent].blocks)
	{
		scene.get()->addItem(block.item.get());
	}
	for (const auto& hazard : levelsAll[levelCurrent].hazards)
	{
		scene.get()->addItem(hazard.item.get());
	}
}

void GameplayScreen::removeCurrentLevelFromScene()
{
	// We remove rather than using QGraphicsScene clear() function,
	// to avoid deleting the items (they need to be reusable).
	for (const auto& key : levelsAll[levelCurrent].keys)
	{
		scene.get()->removeItem(key.item.get());
	}
	for (const auto& gate : levelsAll[levelCurrent].gates)
	{
		scene.get()->removeItem(gate.item.get());
	}
	for (const auto& player : levelsAll[levelCurrent].players)
	{
		scene.get()->removeItem(player.item.get());
	}
	for (const auto& pusher : levelsAll[levelCurrent].pushers)
	{
		scene.get()->removeItem(pusher.item.get());
	}
	for (const auto& sucker : levelsAll[levelCurrent].suckers)
	{
		scene.get()->removeItem(sucker.item.get());
	}
	for (const auto& util : levelsAll[levelCurrent].utils)
	{
		scene.get()->removeItem(util.item.get());
	}
	for (const auto& block : levelsAll[levelCurrent].blocks)
	{
		scene.get()->removeItem(block.item.get());
	}
	for (const auto& hazard : levelsAll[levelCurrent].hazards)
	{
		scene.get()->removeItem(hazard.item.get());
	}
}

void GameplayScreen::uiGameplaySetToDefaults()
{
	uiGameplayUpdateStatCounterTurns();
	uiGameplayUpdateStatCounterPushers();
	uiGameplayUpdateStatCounterSuckers();
	uiGameplayUpdateStatCounterKeys();
	uiGameplayMessagesTextBox.get()->setText("");
}

void GameplayScreen::uiGameplayUpdateStatCounterTurns()
{
	uiGameplayStatsCounterTurns.get()->setText("Turns Remaining: " + QString::number(levelsAll[levelCurrent].turnsRemaining));
}

void GameplayScreen::uiGameplayUpdateStatCounterKeys()
{
	uiGameplayStatsCounterKeys.get()->setText("Keys: " + QString::number(levelsAll[levelCurrent].players[pIndex].heldKeys));
}

void GameplayScreen::uiGameplayUpdateStatCounterPushers()
{
	uiGameplayStatsCounterTrapPushers->setText("Spring Traps: " + QString::number(levelsAll[levelCurrent].players[pIndex].heldUtilPushIndex.size()));
}

void GameplayScreen::uiGameplayUpdateStatCounterSuckers()
{
	uiGameplayStatsCounterTrapSuckers.get()->setText("Magnet Traps: " + QString::number(levelsAll[levelCurrent].players[pIndex].heldUtilSuckIndex.size()));
}

void GameplayScreen::uiMenuResumePlay()
{
	gameState = GameState::PLAYING;
	uiMenuGroup.get()->setVisible(false);
}

void GameplayScreen::updateWindowTitle()
{
	this->parentWidget()->parentWidget()->setWindowTitle
	(
		winTitleProgramName + " - Current Level: " + levelsAll[levelCurrent].name + " by " + levelsAll[levelCurrent].creator
	);
}

QPixmap GameplayScreen::stateToImg(const tokenImmobile::State &state, const tokenImmobile::Type &type)
{
	if (state == tokenImmobile::State::INVISIBLE || state == tokenImmobile::State::HELD)
	{
		return imgInvisible;
	}
	else if (state == tokenImmobile::State::ACTIVE)
	{
		if (type == tokenImmobile::Type::KEY)
			return imgImmobileKey;
		else if (type == tokenImmobile::Type::GATE)
			return imgImmobileGate;
		else if (type == tokenImmobile::Type::BLOCK)
			return imgImmobileBlock;
		else if (type == tokenImmobile::Type::HAZARD)
			return imgImmobileHazard;
		else
			return imgError;
	}
	else
		return imgError;
}

QPixmap GameplayScreen::stateToImg(const tokenUtil::State &state, const tokenUtil::Type &type)
{
	if (type == tokenUtil::Type::PUSHER)
	{
		if (state == tokenUtil::State::INACTIVE)
			return imgUtilPusherInactive;
		else if (state == tokenUtil::State::ACTIVE)
			return imgUtilPusherActive;
		else if (state == tokenUtil::State::HELD)
			return imgInvisible;
		else
			return imgError;
	}
	else if (type == tokenUtil::Type::SUCKER)
	{
		if (state == tokenUtil::State::INACTIVE)
			return imgUtilSuckerInactive;
		else if (state == tokenUtil::State::ACTIVE)
			return imgUtilSuckerActive;
		else if (state == tokenUtil::State::HELD)
			return imgInvisible;
		else
			return imgError;
	}
	else
		return imgError;
}

QPixmap GameplayScreen::facingToImg(const tokenPlayer::Facing &facing)
{
	if (facing == tokenPlayer::Facing::NEUTRAL)
		return imgPlayerNeutral;
	else if (facing == tokenPlayer::Facing::UP)
		return imgPlayerUp;
	else if (facing == tokenPlayer::Facing::DOWN)
		return imgPlayerDown;
	else if (facing == tokenPlayer::Facing::LEFT)
		return imgPlayerLeft;
	else if (facing == tokenPlayer::Facing::RIGHT)
		return imgPlayerRight;
	else
		return imgError;
}

QPixmap GameplayScreen::facingToImg(const tokenPatroller::Facing &facing, const tokenPatroller::Type &type)
{
	if (type == tokenPatroller::Type::PUSHER)
	{
		if (facing == tokenPatroller::Facing::UP)
			return imgPatrollerPusherUp;
		else if (facing == tokenPatroller::Facing::DOWN)
			return imgPatrollerPusherDown;
		else if (facing == tokenPatroller::Facing::LEFT)
			return imgPatrollerPusherLeft;
		else if (facing == tokenPatroller::Facing::RIGHT)
			return imgPatrollerPusherRight;
		else
			return imgError;
	}
	else if (type == tokenPatroller::Type::SUCKER)
	{
		if (facing == tokenPatroller::Facing::UP)
			return imgPatrollerSuckerUp;
		else if (facing == tokenPatroller::Facing::DOWN)
			return imgPatrollerSuckerDown;
		else if (facing == tokenPatroller::Facing::LEFT)
			return imgPatrollerSuckerLeft;
		else if (facing == tokenPatroller::Facing::RIGHT)
			return imgPatrollerSuckerRight;
		else
			return imgError;
	}
	else
		return imgError;
}

const QFont::StyleStrategy GameplayScreen::fontStrategyToEnum(const QString &str)
{
	// Default to antialias strat if string received is unexpected.
	// Moxybox uses Pixellari with NoAntialias by default, but most fonts someone
	// would want to use are probably going to want to be used with antialiasing.
	// So in the event of a mod messing up the naming to call the right font,
	// we default to antialiasing.
	if (str == "NoAntialias")
		return QFont::StyleStrategy::NoAntialias;
	else if (str == "NoSubpixelAntialias")
		return QFont::StyleStrategy::NoSubpixelAntialias;
	else if (str == "PreferAntialias")
		return QFont::StyleStrategy::PreferAntialias;
	else
		return QFont::StyleStrategy::PreferAntialias;
}

const QString GameplayScreen::fontStrategyToString(const QFont::StyleStrategy &strat)
{
	if (strat == QFont::StyleStrategy::NoAntialias)
		return "NoAntialias";
	else if (strat == QFont::StyleStrategy::NoSubpixelAntialias)
		return "NoSubpixelAntialias";
	else if (strat == QFont::StyleStrategy::PreferAntialias)
		return "PreferAntialias";
	else
		return "PreferAntialias";
}

const QFont::Weight GameplayScreen::fontWeightToEnum(const QString &str)
{
	if (str == "Normal")
		return QFont::Weight::Normal;
	else if (str == "Thin")
		return QFont::Weight::Thin;
	else if (str == "ExtraLight")
		return QFont::Weight::ExtraLight;
	else if (str == "Light")
		return QFont::Weight::Light;
	else if (str == "Medium")
		return QFont::Weight::Medium;
	else if (str == "DemiBold")
		return QFont::Weight::DemiBold;
	else if (str == "Bold")
		return QFont::Weight::Bold;
	else if (str == "ExtraBold")
		return QFont::Weight::ExtraBold;
	else if (str == "Black")
		return QFont::Weight::Black;
	else
		return QFont::Weight::Normal;
}

const QString GameplayScreen::fontWeightToString(const QFont::Weight &strat)
{
	if (strat == QFont::Weight::Normal)
		return "Normal";
	else if (strat == QFont::Weight::Thin)
		return "Thin";
	else if (strat == QFont::Weight::ExtraLight)
		return "ExtraLight";
	else if (strat == QFont::Weight::Light)
		return "Light";
	else if (strat == QFont::Weight::Medium)
		return "Medium";
	else if (strat == QFont::Weight::DemiBold)
		return "DemiBold";
	else if (strat == QFont::Weight::Bold)
		return "Bold";
	else if (strat == QFont::Weight::ExtraBold)
		return "ExtraBold";
	else if (strat == QFont::Weight::Black)
		return "Black";
	else
		return "Normal";
}

QString GameplayScreen::extractSubstringInbetweenQt(const QString strBegin, const QString strEnd, const QString &strExtractFrom)
{
	QString extracted = "";
	int posFound = 0;

	if (!strBegin.isEmpty() && !strEnd.isEmpty())
	{
		while (strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) != -1)
		{
			int posBegin = strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) + strBegin.length();
			int posEnd = strExtractFrom.indexOf(strEnd, posBegin, Qt::CaseSensitive);
			extracted += strExtractFrom.mid(posBegin, posEnd - posBegin);
			posFound = posEnd;
		}
	}
	else if (strBegin.isEmpty() && !strEnd.isEmpty())
	{
		int posBegin = 0;
		int posEnd = strExtractFrom.indexOf(strEnd, posBegin, Qt::CaseSensitive);
		extracted += strExtractFrom.mid(posBegin, posEnd - posBegin);
		posFound = posEnd;
	}
	else if (!strBegin.isEmpty() && strEnd.isEmpty())
	{
		int posBegin = strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) + strBegin.length();
		int posEnd = strExtractFrom.length();
		extracted += strExtractFrom.mid(posBegin, posEnd - posBegin);
		posFound = posEnd;
	}
	return extracted;
}

QStringList GameplayScreen::extractSubstringInbetweenQtLoopList(const QString strBegin, const QString strEnd, const QString &strExtractFrom)
{
	QStringList extracted;
	int posFound = 0;

	if (!strBegin.isEmpty() && !strEnd.isEmpty())
	{
		while (strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) != -1)
		{
			int posBegin = strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) + strBegin.length();
			int posEnd = strExtractFrom.indexOf(strEnd, posBegin, Qt::CaseSensitive);
			extracted.append(strExtractFrom.mid(posBegin, posEnd - posBegin));
			posFound = posEnd;
		}
	}
	else if (strBegin.isEmpty() && !strEnd.isEmpty())
	{
		int posBegin = 0;
		int posEnd = strExtractFrom.indexOf(strEnd, posBegin, Qt::CaseSensitive);
		extracted.append(strExtractFrom.mid(posBegin, posEnd - posBegin));
		posFound = posEnd;
	}
	else if (!strBegin.isEmpty() && strEnd.isEmpty())
	{
		int posBegin = strExtractFrom.indexOf(strBegin, posFound, Qt::CaseSensitive) + strBegin.length();
		int posEnd = strExtractFrom.length();
		extracted.append(strExtractFrom.mid(posBegin, posEnd - posBegin));
		posFound = posEnd;
	}
	return extracted;
}

void GameplayScreen::modLoadThemeIfExists()
{
	const QString modThemePath = appExecutablePath + "/Mods/Theme/theme.MoxyStyle";
	if (!QFile(modThemePath).exists())
		return;

	QFile fileRead(modThemePath);
	if (fileRead.open(QIODevice::ReadOnly))
	{
		QTextStream qStream(&fileRead);
		while (!qStream.atEnd())
		{
			QString line = qStream.readLine();

			// If a line has // at the beginning, we treat it as a comment and move on.
			// Doing this as a precaution in the event of a comment accidentally containing
			// a key phrase that is used to find something we want and triggering a false positive.
			// And so you can fiddle around with theme file, commenting stuff out to test,
			// without needing to delete it entirely.
			if (line[0] == '/' && line[1] == '/')
				continue;

			if (line.contains("::useTheme="))
			{
				bool useTheme = QVariant(extractSubstringInbetweenQt("::useTheme=", "::", line)).toBool();
				if (!useTheme)
				{
					fileRead.close();
					return;
				}
			}
			else if (line.contains("::standardFontFamily="))
			{
				standardFontFamily = extractSubstringInbetweenQt("::standardFontFamily=", "::", line);
			}
			else if (line.contains("::standardFontStyleStrategy="))
			{
				standardFontStyleStrategy = fontStrategyToEnum(extractSubstringInbetweenQt("::standardFontStyleStrategy=", "::", line));
			}
			else if (line.contains("::standardFontWeight="))
			{
				standardFontWeight = fontWeightToEnum(extractSubstringInbetweenQt("::standardFontWeight=", "::", line));
			}
			else if (line.contains("::uiGameplayFontGroupTitle_fontPointSize="))
			{
				uiGameplayFontGroupTitle_fontPointSize = extractSubstringInbetweenQt("::uiGameplayFontGroupTitle_fontPointSize=", "::", line).toInt();
			}
			else if (line.contains("::uiGameplayFontTextBox_fontPointSize="))
			{
				uiGameplayFontTextBox_fontPointSize = extractSubstringInbetweenQt("::uiGameplayFontTextBox_fontPointSize=", "::", line).toInt();
			}
			else if (line.contains("::uiMenuFontBtn_fontPointSize="))
			{
				uiMenuFontBtn_fontPointSize = extractSubstringInbetweenQt("::uiMenuFontBtn_fontPointSize=", "::", line).toInt();
			}
			else if (line.contains("::baseStyle="))
			{
				baseStyle = extractSubstringInbetweenQt("::baseStyle=", "::", line);
			}
			else if (line.contains("::::uiGameplayGroupBoxStyle="))
			{
				uiGameplayGroupBoxStyle = extractSubstringInbetweenQt("::uiGameplayGroupBoxStyle=", "::::", line);
			}
			else if (line.contains("::uiGameplayTextBoxStyle="))
			{
				uiGameplayTextBoxStyle = extractSubstringInbetweenQt("::uiGameplayTextBoxStyle=", "::", line);
			}
			else if (line.contains("::uiGameplayLabelStyle="))
			{
				uiGameplayLabelStyle = extractSubstringInbetweenQt("::uiGameplayLabelStyle=", "::", line);
			}
			else if (line.contains("::uiGameplayKeymapBtnStyle="))
			{
				uiGameplayKeymapBtnStyle = extractSubstringInbetweenQt("::uiGameplayKeymapBtnStyle=", "::", line);
			}
			else if (line.contains("::uiGameplayKeymapModifBtnStyle="))
			{
				uiGameplayKeymapModifBtnStyle = extractSubstringInbetweenQt("::uiGameplayKeymapModifBtnStyle=", "::", line);
			}
			else if (line.contains("::uiMenuGroupBoxStyle="))
			{
				uiMenuGroupBoxStyle = extractSubstringInbetweenQt("::uiMenuGroupBoxStyle=", "::", line).arg(appExecutablePath);
			}
			else if (line.contains("::uiMenuBtnStyle="))
			{
				uiMenuBtnStyle = extractSubstringInbetweenQt("::uiMenuBtnStyle=", "::", line);
			}
			else if (line.contains("::imgImmobileKey="))
			{
				imgImmobileKey = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgImmobileKey=", "::", line));
			}
			else if (line.contains("::imgImmobileGate="))
			{
				imgImmobileGate = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgImmobileGate=", "::", line));
			}
			else if (line.contains("::imgImmobileBlock="))
			{
				imgImmobileBlock = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgImmobileBlock=", "::", line));
			}
			else if (line.contains("::imgImmobileHazard="))
			{
				imgImmobileHazard = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgImmobileHazard=", "::", line));
			}
			else if (line.contains("::imgPlayerNeutral="))
			{
				imgPlayerNeutral = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPlayerNeutral=", "::", line));
			}
			else if (line.contains("::imgPlayerLeft="))
			{
				imgPlayerLeft = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPlayerLeft=", "::", line));
			}
			else if (line.contains("::imgPlayerRight="))
			{
				imgPlayerRight = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPlayerRight=", "::", line));
			}
			else if (line.contains("::imgPlayerUp="))
			{
				imgPlayerUp = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPlayerUp=", "::", line));
			}
			else if (line.contains("::imgPlayerDown="))
			{
				imgPlayerDown = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPlayerDown=", "::", line));
			}
			else if (line.contains("::imgPatrollerPusherLeft="))
			{
				imgPatrollerPusherLeft = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerPusherLeft=", "::", line));
			}
			else if (line.contains("::imgPatrollerPusherRight="))
			{
				imgPatrollerPusherRight = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerPusherRight=", "::", line));
			}
			else if (line.contains("::imgPatrollerPusherUp="))
			{
				imgPatrollerPusherUp = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerPusherUp=", "::", line));
			}
			else if (line.contains("::imgPatrollerPusherDown="))
			{
				imgPatrollerPusherDown = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerPusherDown=", "::", line));
			}
			else if (line.contains("::imgPatrollerSuckerLeft="))
			{
				imgPatrollerSuckerLeft = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerSuckerLeft=", "::", line));
			}
			else if (line.contains("::imgPatrollerSuckerRight="))
			{
				imgPatrollerSuckerRight = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerSuckerRight=", "::", line));
			}
			else if (line.contains("::imgPatrollerSuckerUp="))
			{
				imgPatrollerSuckerUp = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerSuckerUp=", "::", line));
			}
			else if (line.contains("::imgPatrollerSuckerDown="))
			{
				imgPatrollerSuckerDown = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgPatrollerSuckerDown=", "::", line));
			}
			else if (line.contains("::imgUtilPusherInactive="))
			{
				imgUtilPusherInactive = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgUtilPusherInactive=", "::", line));
			}
			else if (line.contains("::imgUtilPusherActive="))
			{
				imgUtilPusherActive = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgUtilPusherActive=", "::", line));
			}
			else if (line.contains("::imgUtilSuckerInactive="))
			{
				imgUtilSuckerInactive = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgUtilSuckerInactive=", "::", line));
			}
			else if (line.contains("::imgUtilSuckerActive="))
			{
				imgUtilSuckerActive = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgUtilSuckerActive=", "::", line));
			}
			else if (line.contains("::imgGridCornerUpL="))
			{
				imgGridCornerUpL = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridCornerUpL=", "::", line));
			}
			else if (line.contains("::imgGridCornerUpR="))
			{
				imgGridCornerUpR = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridCornerUpR=", "::", line));
			}
			else if (line.contains("::imgGridCornerDownL="))
			{
				imgGridCornerDownL = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridCornerDownL=", "::", line));
			}
			else if (line.contains("::imgGridCornerDownR="))
			{
				imgGridCornerDownR = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridCornerDownR=", "::", line));
			}
			else if (line.contains("::imgGridInner="))
			{
				imgGridInner = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridInner=", "::", line));
			}
			else if (line.contains("::imgGridEdgeUpX="))
			{
				imgGridEdgeUpX = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridEdgeUpX=", "::", line));
			}
			else if (line.contains("::imgGridEdgeDownX="))
			{
				imgGridEdgeDownX = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridEdgeDownX=", "::", line));
			}
			else if (line.contains("::imgGridEdgeLeftY="))
			{
				imgGridEdgeLeftY = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridEdgeLeftY=", "::", line));
			}
			else if (line.contains("::imgGridEdgeRightY="))
			{
				imgGridEdgeRightY = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgGridEdgeRightY=", "::", line));
			}
			else if (line.contains("::imgSplashTitle="))
			{
				imgSplashTitle = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgSplashTitle=", "::", line));
			}
			else if (line.contains("::imgSplashLevelComplete="))
			{
				imgSplashLevelComplete = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgSplashLevelComplete=", "::", line));
			}
			else if (line.contains("::imgSplashLevelFailed="))
			{
				imgSplashLevelFailed = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgSplashLevelFailed=", "::", line));
			}
			else if (line.contains("::imgSplashLevelAllDone="))
			{
				imgSplashLevelAllDone = QPixmap(appExecutablePath + extractSubstringInbetweenQt("::imgSplashLevelAllDone=", "::", line));
			}
		}
		fileRead.close();
	}
}