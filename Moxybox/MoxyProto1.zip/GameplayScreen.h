#pragma once

#include <QCoreApplication>
#include <QGraphicsView>
#include <QGraphicsScene>
#include <QGraphicsPixmapItem>
#include <QDirIterator>
#include <QTextStream>
#include <QShortcut>
#include <QKeyEvent>
#include <QGridLayout>
#include <QGroupBox>
#include <QFont>
#include <QTextBrowser>
#include <QLineEdit>
#include <QLabel>
#include <QPushButton>
#include <QFileDialog>
#include <QDateTime>
#include <QMessageBox>
#include <QDebug>
#include <QFileInfo>
#include <algorithm>

class GameplayScreen : public QGraphicsView
{
	Q_OBJECT

public:
	GameplayScreen(QWidget *parent = nullptr);
	void prefSave();

protected:
	void keyReleaseEvent(QKeyEvent *event);

private:

	std::unique_ptr<QGraphicsScene> scene = std::make_unique<QGraphicsScene>();

	const QString appExecutablePath = QCoreApplication::applicationDirPath();
	const QString levelDataPath = appExecutablePath + "/LevelData";
	const QString levelDataFileExtension = "MoxyLvl";

	QString fileDirLastSaved = appExecutablePath + "/Saves";
	QString fileDirLastOpened = appExecutablePath + "/Saves";

	const QString winTitleProgramName = "Moxybox";

	QString baseStyle = "border: 0px; background-color: #000000;";
	QString standardFontFamily = "Pixellari";
	QFont::StyleStrategy standardFontStyleStrategy = QFont::NoAntialias;
	QFont::Weight standardFontWeight = QFont::Normal;
	int uiGameplayFontGroupTitle_fontPointSize = 12;
	int uiGameplayFontTextBox_fontPointSize = 12;
	int uiMenuFontBtn_fontPointSize = 14;

	enum class GameState { TITLE, PLAYING, PAUSED, KEYBINDING, LEVEL_COMPLETE, LEVEL_FAILED, LEVEL_ALL_DONE };
	GameState gameState = GameState::TITLE;

	// This is a turn-based game, so we process moves in order: Player -> Patrollers -> Player -> Patrollers -> Etc.
	// Player controls the start of a turn and patrollers end it.
	// Turn ownership determines who is expected to move next. We initialize it as none, since the game starts on
	// an intro splash screen and player should not be able to move until everything is ready for the first level.
	// Once the first level is ready, turn ownership should be set to Player, so they can begin the game.
	enum class TurnOwner { NONE, PLAYER, PATROLLER };
	TurnOwner turnOwner = TurnOwner::NONE;

	// We set up an enum ID for each modifiable keybind, so that when the UI is clicked
	// to modify a key, we know which one to apply the modification to after key input.
	enum class KeybindModifiable
	{
		NONE,
		MOVE_LEFT,
		MOVE_RIGHT,
		MOVE_UP,
		MOVE_DOWN,
		PLACE_PUSHER_UTIL,
		PLACE_SUCKER_UTIL,
		OPEN_MENU
	};
	KeybindModifiable keybindToModify = KeybindModifiable::NONE;

	Qt::Key keybindMoveLeft = Qt::Key::Key_A;
	Qt::Key keybindMoveRight = Qt::Key::Key_D;
	Qt::Key keybindMoveUp = Qt::Key::Key_W;
	Qt::Key keybindMoveDown = Qt::Key::Key_S;

	Qt::Key keybindPlacePusherUtil = Qt::Key::Key_Q;
	Qt::Key keybindPlaceSuckerUtil = Qt::Key::Key_E;

	Qt::Key keybindOpenMenu = Qt::Key::Key_Escape;
	const Qt::Key keybindNextLevel = Qt::Key::Key_Space;
	const Qt::Key keybindResetLevel = Qt::Key::Key_R;

	// -------
	// TOKEN
	// -------
	// Currently there is only one possible player, so the player object accessed
	// should always be the first (and only) one in the players object vector (index 0).
	// You may be wondering: Why store the object in a vector at all if there is only one.
	// Reason: This is done to simplify the data storing/loading process for levels and keep it the same for all types of data.
	// It also leaves less obstacles to changing players to have more than one in the future, if desired.
	int pIndex = 0;

	// Unlike other images used in the program, "invisible" and "error" do not have a thematic purpose.
	// Meaning, there is no expectation of, or point to, them being changed as part of a mod theme.
	// So we make them const, unlike the rest of the images.
	const QPixmap imgInvisible = QPixmap(":/Moxybox/Resources/invisible.png");
	const QPixmap imgError = QPixmap(":/Moxybox/Resources/error.png");

	QPixmap imgImmobileKey = QPixmap(":/Moxybox/Resources/tokenImmobileKey.png");
	QPixmap imgImmobileGate = QPixmap(":/Moxybox/Resources/tokenImmobileGate.png");
	QPixmap imgImmobileBlock = QPixmap(":/Moxybox/Resources/tokenImmobileBlock.png");
	QPixmap imgImmobileHazard = QPixmap(":/Moxybox/Resources/tokenImmobileHazard.png");

	// By default, player token uses the same image (under different names), no matter what its "facing" direction is.
	// But we support a different image based on facing orientation regardless, to account for if
	// a mod theme wants to use a player token that has different images for its facing direction.
	// We include a neutral facing direction too. This is the direction player always starts in
	// and the direction it changes to when deploying a utility item, rather than moving.
	QPixmap imgPlayerNeutral = QPixmap(":/Moxybox/Resources/tokenPlayerNeutral.png");
	QPixmap imgPlayerLeft = QPixmap(":/Moxybox/Resources/tokenPlayerLeft.png");
	QPixmap imgPlayerRight = QPixmap(":/Moxybox/Resources/tokenPlayerRight.png");
	QPixmap imgPlayerUp = QPixmap(":/Moxybox/Resources/tokenPlayerUp.png");
	QPixmap imgPlayerDown = QPixmap(":/Moxybox/Resources/tokenPlayerDown.png");

	QPixmap imgPatrollerPusherLeft = QPixmap(":/Moxybox/Resources/tokenPatrollerPusherLeft.png");
	QPixmap imgPatrollerPusherRight = QPixmap(":/Moxybox/Resources/tokenPatrollerPusherRight.png");
	QPixmap imgPatrollerPusherUp = QPixmap(":/Moxybox/Resources/tokenPatrollerPusherUp.png");
	QPixmap imgPatrollerPusherDown = QPixmap(":/Moxybox/Resources/tokenPatrollerPusherDown.png");
	QPixmap imgPatrollerSuckerLeft = QPixmap(":/Moxybox/Resources/tokenPatrollerSuckerLeft.png");
	QPixmap imgPatrollerSuckerRight = QPixmap(":/Moxybox/Resources/tokenPatrollerSuckerRight.png");
	QPixmap imgPatrollerSuckerUp = QPixmap(":/Moxybox/Resources/tokenPatrollerSuckerUp.png");
	QPixmap imgPatrollerSuckerDown = QPixmap(":/Moxybox/Resources/tokenPatrollerSuckerDown.png");

	QPixmap imgUtilPusherInactive = QPixmap(":/Moxybox/Resources/tokenUtilPusherInactive.png");
	QPixmap imgUtilPusherActive = QPixmap(":/Moxybox/Resources/tokenUtilPusherActive.png");
	QPixmap imgUtilSuckerInactive = QPixmap(":/Moxybox/Resources/tokenUtilSuckerInactive.png");
	QPixmap imgUtilSuckerActive = QPixmap(":/Moxybox/Resources/tokenUtilSuckerActive.png");

	// Z value for mobile tokens should be higher than that of grid pieces to be atop them.
	// And higher than that of immobile tokens (ex: player would be atop utility token).
	const int tokenMobileZ = 2;
	const int tokenImmobileZ = 1;

	const int tokenSize = 20; // Standard image size of all tokens. Unused, from SDL2 version of game.
	struct tokenPlayer
	{
		const int initialX;
		const int initialY;
		enum class Facing { NEUTRAL, UP, DOWN, LEFT, RIGHT };
		Facing facing = Facing::NEUTRAL;
		int heldKeys = 0;
		std::vector<int> heldUtilPushIndex;
		std::vector<int> heldUtilSuckIndex;
		int movementSpeed = 1; // This only checks collision for square landed on, so keep this in mind if changing it (it could break level design)
		int knockbackAmount = 2; // Be careful about what this is set to. Collision detection is likely expensive and runs for each square pushed back
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);
	};
	struct tokenPatroller
	{
		// Patrollers use initial Y/X values along with bound points to leash their patrol path.
		// Make sure bound points keep each patroller within the bounds of the grid and not colliding with anything silly.
		// Patrollers have no collision detection for screen or objects (other than player), so you must consciously set 
		// their patrol bounds to avoid silly behavior. Level creation tool should leash their path within grid bound
		// on save, automatically.

		// Note: Patrol direction, type, patrol bound, are const at level load, so
		// we don't need to save or load them as part of save game file.
		// (not to be confused with level data file)

		const int initialX;
		const int initialY;
		enum class Type { PUSHER, SUCKER, ERROR };
		const Type type = Type::PUSHER;
		enum class Facing { UP, DOWN, LEFT, RIGHT, ERROR };
		const Facing facingInitial = Facing::UP;
		Facing facing = Facing::UP;
		enum class PatrolDir { VERTICAL, HORIZONTAL, ERROR };
		const PatrolDir patrolDir = PatrolDir::VERTICAL;
		const int patrolBoundUp = 3;
		const int patrolBoundDown = 3;
		const int patrolBoundLeft = 3;
		const int patrolBoundRight = 3;
		int movementSpeed = 1;
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);

		static const Facing facingToEnum(const QString &str)
		{
			if (str == "UP")
				return Facing::UP;
			else if (str == "DOWN")
				return Facing::DOWN;
			else if (str == "LEFT")
				return Facing::LEFT;
			else if (str == "RIGHT")
				return Facing::RIGHT;
			else
				return Facing::ERROR;
		}

		static const QString facingToString(const Facing &facing)
		{
			if (facing == Facing::UP)
				return "UP";
			else if (facing == Facing::DOWN)
				return "DOWN";
			else if (facing == Facing::LEFT)
				return "LEFT";
			else if (facing == Facing::RIGHT)
				return "RIGHT";
			else
				return "ERROR";
		}

		static const PatrolDir patrolDirToEnum(const QString &str)
		{
			if (str == "VERTICAL")
				return PatrolDir::VERTICAL;
			else if (str == "HORIZONTAL")
				return PatrolDir::HORIZONTAL;
			else
				return PatrolDir::ERROR;
		}

		static const QString patrolDirToString(const PatrolDir &patrolDir)
		{
			if (patrolDir == PatrolDir::VERTICAL)
				return "VERTICAL";
			else if (patrolDir == PatrolDir::HORIZONTAL)
				return "HORIZONTAL";
			else
				return "ERROR";
		}

		static const Type typeToEnum(const QString &str)
		{
			if (str == "PUSHER")
				return Type::PUSHER;
			else if (str == "SUCKER")
				return Type::SUCKER;
			else
				return Type::ERROR;
		}

		static const QString typeToString(const Type &type)
		{
			if (type == Type::PUSHER)
				return "PUSHER";
			else if (type == Type::SUCKER)
				return "SUCKER";
			else
				return "ERROR";
		}
	};
	struct tokenImmobile
	{
		const int initialX;
		const int initialY;
		enum class Type { BLOCK, KEY, GATE, HAZARD, ERROR };
		Type type = Type::BLOCK;
		enum class State { ACTIVE, INVISIBLE, HELD, ERROR };
		State state = State::ACTIVE;
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);

		static const State stateToEnum(const QString &str)
		{
			if (str == "ACTIVE")
				return State::ACTIVE;
			else if (str == "INVISIBLE")
				return State::INVISIBLE;
			else if (str == "HELD")
				return State::HELD;
			else
				return State::ERROR;
		}

		static const QString stateToString(const State &state)
		{
			if (state == State::ACTIVE)
				return "ACTIVE";
			else if (state == State::INVISIBLE)
				return "INVISIBLE";
			else if (state == State::HELD)
				return "HELD";
			else
				return "ERROR";
		}

		static const Type typeToEnum(const QString &str)
		{
			if (str == "BLOCK")
				return Type::BLOCK;
			else if (str == "KEY")
				return Type::KEY;
			else if (str == "GATE")
				return Type::GATE;
			else if (str == "HAZARD")
				return Type::HAZARD;
			else
				return Type::ERROR;
		}

		static const QString typeToString(const Type &type)
		{
			if (type == Type::BLOCK)
				return "BLOCK";
			else if (type == Type::KEY)
				return "KEY";
			else if (type == Type::GATE)
				return "GATE";
			else if (type == Type::HAZARD)
				return "HAZARD";
			else
				return "ERROR";
		}
	};
	struct tokenUtil
	{
		// Note:
		// Traps don't change patrol route of patrollers.
		// Suck trap can change the axis the patroller is patrolling on, if it's an axis that isn't their patrol axis.
		// e.g. if patrolling on X axis, they can be sucked down or up to another Y row in the grid.
		// They will stay on that Y unless sucked again in another Y direction,
		// because their patrol route is leashed to X axis, not to Y axis.

		const int initialX;
		const int initialY;
		enum class Type { PUSHER, SUCKER, ERROR };
		Type type = Type::PUSHER;
		enum class State { INACTIVE, ACTIVE, HELD, ERROR };
		const State stateBase = State::INACTIVE; // Unchanged state, pulled from level data file, reset state to this.
		State stateModified = State::INACTIVE; // Changeable state, for use in the middle of playing a level.
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);

		static Type typeToEnum(const QString &str)
		{
			if (str == "PUSHER")
				return Type::PUSHER;
			else if (str == "SUCKER")
				return Type::SUCKER;
			else
				return Type::ERROR;
		}

		static const QString typeToString(const Type &type)
		{
			if (type == Type::PUSHER)
				return "PUSHER";
			else if (type == Type::SUCKER)
				return "SUCKER";
			else
				return "ERROR";
		}

		static const State stateToEnum(const QString &str)
		{
			if (str == "INACTIVE")
				return State::INACTIVE;
			else if (str == "ACTIVE")
				return State::ACTIVE;
			else if (str == "HELD")
				return State::HELD;
			else
				return State::ERROR;
		}

		static const QString stateToString(const State &state)
		{
			if (state == State::INACTIVE)
				return "INACTIVE";
			else if (state == State::ACTIVE)
				return "ACTIVE";
			else if (state == State::HELD)
				return "HELD";
			else
				return "ERROR";
		}
	};

	// ------
	// GRID
	// ------
	struct gridPieceInner // No facing orientation needed (appearance identical no matter rotation)
	{
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);
	};
	struct gridPieceEdge // Facing orientation is based on up/down/left/right
	{
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);
		enum class Facing { UP, DOWN, LEFT, RIGHT };
		Facing facing = Facing::UP;
	};
	struct gridPieceCorner // Facing orientation is based on upperLeft/upperRight/lowerLeft/lowerRight
	{
		std::unique_ptr<QGraphicsPixmapItem> item = std::make_unique<QGraphicsPixmapItem>(nullptr);
		enum class Facing { UP_LEFT, UP_RIGHT, DOWN_LEFT, DOWN_RIGHT };
		Facing facing = Facing::UP_LEFT;
	};
	std::vector<gridPieceInner> gridPiecesInner;
	std::vector<gridPieceEdge> gridPiecesEdge;
	std::vector<gridPieceCorner> gridPiecesCorner;

	// Note that there's some framework lingering here from a scrapped feature to have grid size modifiable by level.
	// As well as a scrapped framework to have the size of grid pieces modifiable (for zooming and the like).
	// (Both are from an SLD2 version of the game, where implementation details are different.)
	// This has been scrapped, setting everything to const, though some of the framework details may linger.
	// If you want to make grid row/col size modifiable, for example, you'll need to remove their const flag.
	// If you want to change grid piece size, it's probably easier to use QGraphicsView's "scaling".
	const int gridPieceZ = 0; // Z value for grid pieces should be lower than that of tokens to be under them.
	const int gridRowSize = 20; // This should not be higher than screenWidth / gridPieceSize
	const int gridColSize = 10; // This should not be higher than ((2/3rds of screenHeight) / gridPieceSize) to have room for UI below it
	const int gridPieceSizeDefault = 40;
	const int gridPieceSize = gridPieceSizeDefault;
	const int gridPieceSizeDstMultiplier = 2;
	const int gridPieceSizeSrc = 40;
	const int gridAnchorX = 0;
	const int gridAnchorY = 0;
	const int gridWidth = gridRowSize * gridPieceSize;
	const int gridHeight = gridColSize * gridPieceSize;
	const int gridBoundUp = gridAnchorY;
	const int gridBoundDown = gridHeight + gridAnchorY;
	const int gridBoundLeft = gridAnchorX;
	const int gridBoundRight = gridWidth + gridAnchorX;

	const int screenWidth = 800;
	const int screenHeight = 600;

	QPixmap imgGridCornerUpL = QPixmap(":/Moxybox/Resources/gridTextureCornerUpL.png");
	QPixmap imgGridCornerUpR = QPixmap(":/Moxybox/Resources/gridTextureCornerUpR.png");
	QPixmap imgGridCornerDownL = QPixmap(":/Moxybox/Resources/gridTextureCornerDownL.png");
	QPixmap imgGridCornerDownR = QPixmap(":/Moxybox/Resources/gridTextureCornerDownR.png");
	QPixmap imgGridInner = QPixmap(":/Moxybox/Resources/gridTextureInner.png");
	QPixmap imgGridEdgeUpX = QPixmap(":/Moxybox/Resources/gridTextureEdgeUpX.png");
	QPixmap imgGridEdgeDownX = QPixmap(":/Moxybox/Resources/gridTextureEdgeDownX.png");
	QPixmap imgGridEdgeLeftY = QPixmap(":/Moxybox/Resources/gridTextureEdgeLeftY.png");
	QPixmap imgGridEdgeRightY = QPixmap(":/Moxybox/Resources/gridTextureEdgeRightY.png");

	// ------------
	// LEVEL DATA
	// ------------
	int levelCurrent = 0;
	int levelsFound;
	int levelsComplete = 0;
	int levelsRemaining = 0;
	struct levelData
	{
		QString id;
		QString creator;
		QString name;
		int difficulty;
		int turnsInitial;
		int turnsRemaining;
		enum class State { COMPLETE, STARTED, UNTOUCHED };
		State state = State::UNTOUCHED;

		std::vector<tokenPlayer> players;
		std::vector<tokenPatroller> pushers;
		std::vector<tokenPatroller> suckers;
		std::vector<tokenImmobile> blocks;
		std::vector<tokenImmobile> keys;
		std::vector<tokenImmobile> gates;
		std::vector<tokenImmobile> hazards;
		std::vector<tokenUtil> utils;
	};
	std::vector<levelData> levelsAll;

	// --------------
	// SPLASHSCREEN
	// --------------
	const int splashZ = 10; // Should have a higher Z value than other things to make sure splash screen shows.
	std::unique_ptr<QGraphicsPixmapItem> splashItem = std::make_unique<QGraphicsPixmapItem>(nullptr);
	QPixmap imgSplashTitle = QPixmap(":/Moxybox/Resources/splashTitle.png");
	QPixmap imgSplashLevelComplete = QPixmap(":/Moxybox/Resources/splashLevelComplete.png");
	QPixmap imgSplashLevelFailed = QPixmap(":/Moxybox/Resources/splashLevelFailed.png");
	QPixmap imgSplashLevelAllDone = QPixmap(":/Moxybox/Resources/splashVictoryOverAll.png");

	// -------------
	// UI GAMEPLAY
	// -------------
	const int uiGameplayKeymapBtnSize = 20;

	QFont uiGameplayFontGroupTitle;
	QFont uiGameplayFontTextBox;

	std::unique_ptr<QGroupBox> uiGameplayGroup = std::make_unique<QGroupBox>(this);
	std::unique_ptr<QGridLayout> uiGameplayLayout = std::make_unique<QGridLayout>();

	std::unique_ptr<QGroupBox> uiGameplayStatsGroup = std::make_unique<QGroupBox>();
	std::unique_ptr<QGroupBox> uiGameplayObjectivesGroup = std::make_unique<QGroupBox>();
	std::unique_ptr<QGroupBox> uiGameplayMessagesGroup = std::make_unique<QGroupBox>();
	std::unique_ptr<QGroupBox> uiGameplayKeymapGroup = std::make_unique<QGroupBox>();

	std::unique_ptr<QGridLayout> uiGameplayStatsLayout = std::make_unique<QGridLayout>();
	std::unique_ptr<QGridLayout> uiGameplayObjectivesLayout = std::make_unique<QGridLayout>();
	std::unique_ptr<QGridLayout> uiGameplayMessagesLayout = std::make_unique<QGridLayout>();
	std::unique_ptr<QGridLayout> uiGameplayKeymapLayout = std::make_unique<QGridLayout>();

	std::unique_ptr<QLabel> uiGameplayStatsCounterKeys = std::make_unique<QLabel>();
	std::unique_ptr<QLabel> uiGameplayStatsCounterTrapPushers = std::make_unique<QLabel>();
	std::unique_ptr<QLabel> uiGameplayStatsCounterTrapSuckers = std::make_unique<QLabel>();

	std::unique_ptr<QLabel> uiGameplayStatsCounterTurns = std::make_unique<QLabel>();

	std::unique_ptr<QTextBrowser> uiGameplayObjectivesTextBox = std::make_unique<QTextBrowser>();
	std::unique_ptr<QTextBrowser> uiGameplayMessagesTextBox = std::make_unique<QTextBrowser>();

	std::unique_ptr<QPushButton> uiGameplayKeymapBtnMoveLeft = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelMoveLeft = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnMoveRight = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelMoveRight = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnMoveUp = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelMoveUp = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnMoveDown = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelMoveDown = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnPlacePusherUtil = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelPlacePusherUtil = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnPlaceSuckerUtil = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelPlaceSuckerUtil = std::make_unique<QLabel>();
	std::unique_ptr<QPushButton> uiGameplayKeymapBtnOpenMenu = std::make_unique<QPushButton>();
	std::unique_ptr<QLabel> uiGameplayKeymapLabelOpenMenu = std::make_unique<QLabel>();

	const QString uiGameplayKeymapGroupTitleDefault = "Keybinds";
	const QString uiGameplayKeymapGroupTitleKeybinding = "Hit Key to Set";

	QString uiGameplayGroupBoxStyle =
	{
		"QGroupBox { border-width: 1px;  border-style: solid;  border-color: #8E7320; background-color: #674003; }"
		"QGroupBox::title { border-width: 1px;  border-top-width: 0px;  border-style: solid;  border-color: #191405;  background-color: #8D9E45;  color: #191405;  subcontrol-origin: margin;  left: 5px; }"
	};

	const int minBoxWidth = (screenWidth / 4) - 6;

	QString uiGameplayTextBoxStyle =
	{
		"QTextEdit { border: 0px;  background-color: #674003;  color: #C4BB81; }"
	};

	QString uiGameplayLabelStyle =
	{
		"QLabel { border: 0px;  background-color: #674003;  color: #C4BB81; }"
	};

	QString uiGameplayKeymapBtnStyle =
	{
		"QPushButton { border-width: 1px;  border-style: solid;  border-color: #674003;  background-color: #674003;  color: #C4BB81; }"
	};

	QString uiGameplayKeymapModifBtnStyle =
	{
		"QPushButton { border-width: 1px;  border-style: solid;  border-color: #191405;  background-color: #8D9E45;  color: #191405; }"
	};

	const QString uiGameplayMessagesObstacle = "Need force of impact to get past obstacles.";
	const QString uiGameplayMessagesHazard = "Need knockback impact to cross hazards. Careful! If you land on it, you have to start the level over.";
	const QString uiGameplayMessagesKeyObtained = "You got a key! Keys can be used to open pods.";
	const QString uiGameplayMessagesKeyNeeded = "Key needed to open pod.";
	const QString uiGameplayMessagesTrapPusherObtained = "You picked up a Spring Trap! Spring traps will knock back patrollers who hit them.";
	const QString uiGameplayMessagesTrapPusherDeployed = "Spring Trap deployed.";
	const QString uiGameplayMessagesTrapSuckerObtained = "You picked up a Magnet Trap! Magnet Traps will pull in patrollers who come near.";
	const QString uiGameplayMessagesTrapSuckerDeployed = "Magnet Trap deployed.";

	// ---------
	// UI MENU
	// ---------
	QFont uiMenuFontBtn;

	const int uiMenuBtnWidth = 214;
	const int uiMenuBtnHeight = 50;
	const int uiMenuBtnMinRowHeight = 75;

	std::unique_ptr<QGroupBox> uiMenuGroup = std::make_unique<QGroupBox>(this);
	std::unique_ptr<QGridLayout> uiMenuLayout = std::make_unique<QGridLayout>();
	std::unique_ptr<QPushButton> uiMenuBtnResume = std::make_unique<QPushButton>();
	std::unique_ptr<QPushButton> uiMenuBtnSave = std::make_unique<QPushButton>();
	std::unique_ptr<QPushButton> uiMenuBtnLoad = std::make_unique<QPushButton>();
	std::unique_ptr<QPushButton> uiMenuBtnReset = std::make_unique<QPushButton>();
	std::unique_ptr<QPushButton> uiMenuBtnExit = std::make_unique<QPushButton>();

	QString uiMenuGroupBoxStyle =
	{
		"QGroupBox { background-image: url(:/Moxybox/Resources/uiMenuBtsBg.png); }"
	};

	QString uiMenuBtnStyle =
	{
		"QPushButton { background-color: rgba(255, 255, 255, 0);  border: none;  color: #C4BB81;  image: url(:/Moxybox/Resources/invisible.png); }"
	};

	// -----------
	// FUNCTIONS
	// -----------
	void prefLoad();
	bool hitSolidObjectPlayerMoving();
	bool hitImmobileObject(const std::vector<tokenImmobile>& immobiles, const int playerNextY, const int playerNextX);
	bool hitImmobileObjectAndDelete(std::vector<tokenImmobile>& immobiles, const int playerNextY, const int playerNextX);
	bool hitUtil(const int playerNextY, const int playerNextX);
	bool hitEnemy(const std::vector<tokenPatroller>& patrollers, const int playerNextY, const int playerNextX);
	void knockbackPlayerMoving();
	void updatePositionPatrollers();
	void updatePositionPatrollerMoves(std::vector<tokenPatroller>& patrollers, const int enemyNum);
	void knockbackEnemyMoving(int enemyNum);
	bool patrollerHitTrapPush(const std::vector<tokenPatroller>& patrollers, const int enemyNum, const int patrollerNextY, const int patrollerNextX);
	void knockbackHitTrap(std::vector<tokenPatroller>& patrollers, const int enemyNum);
	bool hitPlayer(const std::vector<tokenPatroller>& patrollers, const int enemyNum);
	void suckInHitTrap(std::vector<tokenPatroller>& patrollers, const int enemyNum);
	void suckInHitCheck();
	void suckInRange();
	void hazardHitCheck();
	void levelSetFailed();
	void levelSetToDefaults(levelData& level);
	void levelSetComplete();
	int levelLoadValidateId(QFile &file);
	int levelFoundInListAtPos(const QString &id);
	int levelFoundInList(const QString &id);
	bool allGatesOpened();
	void addCurrentLevelToScene();
	void removeCurrentLevelFromScene();
	void uiGameplaySetToDefaults();
	void uiGameplayUpdateStatCounterTurns();
	void uiGameplayUpdateStatCounterKeys();
	void uiGameplayUpdateStatCounterPushers();
	void uiGameplayUpdateStatCounterSuckers();
	void uiMenuResumePlay();
	void updateWindowTitle();
	QPixmap stateToImg(const tokenImmobile::State &state, const tokenImmobile::Type &type);
	QPixmap stateToImg(const tokenUtil::State &state, const tokenUtil::Type &type);
	QPixmap facingToImg(const tokenPlayer::Facing &facing);
	QPixmap facingToImg(const tokenPatroller::Facing &facing, const tokenPatroller::Type &type);
	const QFont::StyleStrategy fontStrategyToEnum(const QString &str);
	const QString fontStrategyToString(const QFont::StyleStrategy &strat);
	const QFont::Weight fontWeightToEnum(const QString &str);
	const QString fontWeightToString(const QFont::Weight &strat);
	QString extractSubstringInbetweenQt(const QString strBegin, const QString strEnd, const QString &strExtractFrom);
	QStringList extractSubstringInbetweenQtLoopList(const QString strBegin, const QString strEnd, const QString &strExtractFrom);
	void modLoadThemeIfExists();
};